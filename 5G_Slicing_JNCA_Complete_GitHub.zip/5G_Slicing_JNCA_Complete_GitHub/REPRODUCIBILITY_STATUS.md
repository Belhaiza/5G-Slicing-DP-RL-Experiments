# Reproducibility and provenance

## Source provenance

- Experiments 1--2 and capacity stress: user-uploaded `5G_Slicing_Experiments_1_2_GitHub(1).zip`.
- Experiment 3: user-uploaded `exp3_experiment3_github_portable(1).zip`.
- Experiment 4 anchored PPO: user-uploaded `experiment4_github_clean(1).zip`.
- Experiment 4 CMDP and constrained PPO: user-uploaded `Experiment4_GitHub_CMDP_verified_PPO_candidate(1).zip`.
- Experiment 5 ablation and stress: existing research archives `exp5_ablation_pilot.zip` and `exp5_ablation_stress_validated.zip` from the working session. Their archived results were **not regenerated** as part of packaging.

## Known limitations

1. Exp 4 packages represent separate versions; a paper-matched canonical training protocol must be verified.
2. Exp 5 main ablation uses 12 simulations of 3000 slots, with no burn-in; stress tests use 12 seeds, 500 burn-in and 2500 measured slots. These are not necessarily identical to every final manuscript evaluation protocol.
3. The static capacity-stress baseline is simulation-calibrated, not globally proven optimal.
4. Reported solve times depend on platform; archived values are not universal.
5. A source-code compilation and a short smoke test do not reproduce all results.
6. Archived result files and checkpoints are retained as supplied; they should not be described as freshly regenerated.
7. Shared random seeds do not imply exact common random number coupling when policy-dependent Poisson rates differ.

## Suggested publication checklist

- [ ] Confirm final manuscript tables/figures match archived CSV and PNG files.
- [ ] Confirm RL hyperparameters, update counts, seeds, and evaluation trajectory initialization.
- [ ] Run complete DP/RL/CMDP experiments from clean environment.
- [ ] Validate all CLI entry points and save terminal logs.
- [ ] Check repository history for private data or credentials before making public.

- [ ] Decide whether to adopt `LICENSE_PROPOSED_MIT.txt`; it is **not** an active license until approved.

## Packaging-time checks

- Python syntax checked for all 31 Python scripts: passed.
- Experiment 3 `verify.py`: passed for C=20, 50, and 100 (action ordering, feasibility, reward and sampled transitions).
- Experiment 5 small-instance value-iteration smoke test at C=8: completed 100 iterations without an exception; this is not a convergence or full-result validation.
