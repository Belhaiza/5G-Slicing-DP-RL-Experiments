from pathlib import Path
import ast
root=Path(__file__).resolve().parent
py=list(root.glob('experiments/**/*.py'))
errors=[]
for path in py:
 try: ast.parse(path.read_text(encoding='utf-8-sig'),filename=str(path))
 except Exception as e: errors.append(f'{path.relative_to(root)}: {e}')
print(f'Checked syntax for {len(py)} Python scripts')
if errors:
 print('\n'.join(errors));raise SystemExit(1)
print('PASS: all Python files parsed')
