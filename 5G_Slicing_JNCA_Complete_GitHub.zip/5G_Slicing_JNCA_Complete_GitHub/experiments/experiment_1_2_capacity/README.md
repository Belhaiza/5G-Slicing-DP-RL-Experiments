# 5G network slicing: Experiments 1 and 2, plus capacity-stress extension

Reproducibility materials for the two-class Markov decision process for admission control and pricing. The original Experiment 1 concerns price sensitivity and service dynamics; original Experiment 2 concerns scalability of exact discounted dynamic programming. The new Section 6.4 capacity-stress experiment is provided separately under `results/capacity_stress/`.

## Environment
Python 3.10+ recommended. `python -m pip install -r requirements.txt`

## Original Experiments 1 and 2
`python run_original_experiments.py --experiment 1 --output reproduced/experiment_1`
`python run_original_experiments.py --experiment 2 --output reproduced/experiment_2`

**Important:** The original script's Experiment 2 includes `C=200` in addition to the manuscript table's `C=20,50,75,100,150`; filter the generated CSV accordingly for the printed table. Execution times depend strongly on hardware, BLAS, and software environment and should not be expected to reproduce exactly. Original Experiment 1 uses 10 Monte Carlo replications of 3000 slots per parameter combination.

## Capacity-stress extension (new Section 6.4)
The extension changes arrival multipliers to 0.5, 2, 5 and the maximum per-class admission quota from 2 to 4, while retaining the original economic parameters and `C=50`. The `src/exp_capacity_validation_v4.py` and supporting scripts contain the original scenario evaluation implementation. The policy-audit script is `src/audit.py`; it expects the scenario policy files and run configurations in `results/capacity_stress/`, so use that directory as the working directory or adapt paths if necessary. Raw summary/per-seed/action-audit outputs and saved policy arrays are included.

**Evaluation protocol:** 20 seeds per regime, 1,000 burn-in slots plus 10,000 measured slots per seed. Policy audits used 200,000 measured slots. DP optimizes discounted reward (gamma=0.99); simulated reward per slot is an average-reward estimate. The two-stage simulation search for the static policy does not prove global optimality. Paired-seed confidence intervals do not implement synchronized common random numbers. Capacity pressure is a counterfactual immediate-action feasibility indicator, not a customer blocking rate.

## Data provenance and limits
- `results/experiment_2/exp2_dp_scalability_clean.csv` is the previously reported numeric table; rerun the code for environment-specific measurements.
- `results/experiment_1/manuscript_table_transcription.csv` transcribes the nine values supplied in the manuscript. **The original per-replication CSV for Experiment 1 was not available in this working environment**, so this transcription is not presented as raw simulation data. Rerun Experiment 1 to regenerate full outputs.
- The figures in `figures/` are retained previously generated images. Some may have been generated in a separate plotting pipeline. Treat these as archival figure artifacts; regenerate and verify from data before claiming exact visual reproducibility.
- The manuscript LaTeX is provided for Section 6.4 only, not the entire paper.

## Model parameters
`rH=2, rL=1; pricesH=[1,2,3]; pricesL=[0.75,1.5,2.25]; lambda0H=5; lambda0L=7; betaH=0.60; betaL=0.70; muH=0.25; muL=0.20; gamma=0.99; kappa=0.15; xiH=0.25; xiL=0.15`. Original quota maximum is 2 for each class.

## Public release checklist
Before posting, rerun both original experiments, verify all table entries and figures against generated outputs, test the package on a clean Python environment, and add author/license/citation information appropriate to your manuscript. No proprietary data or personal credentials are intentionally included.
