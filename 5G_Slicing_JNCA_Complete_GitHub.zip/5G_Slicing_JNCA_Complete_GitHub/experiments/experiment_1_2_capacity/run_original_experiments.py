"""Run the original experiments (1: elasticity/service; 2: DP scalability)."""
import argparse
from pathlib import Path
from src.revision_experiments_dp import exp1, exp2

p=argparse.ArgumentParser()
p.add_argument('--experiment', choices=['1','2','both'], required=True)
p.add_argument('--output', default='reproduced')
a=p.parse_args()
o=Path(a.output); o.mkdir(parents=True, exist_ok=True)
if a.experiment in ('1','both'): exp1(str(o))
if a.experiment in ('2','both'): exp2(str(o))
