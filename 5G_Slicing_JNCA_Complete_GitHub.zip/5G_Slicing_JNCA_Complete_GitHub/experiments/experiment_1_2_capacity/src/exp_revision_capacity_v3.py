"""Capacity study v2: independently tuned static policies and load calibration.
Static baseline uses fixed posted prices and target quotas; quotas are clipped
premium-first to satisfy pre-departure capacity. Training and test RNG streams
are disjoint. Static candidates are ranked by multiple independent simulation
replicates, finalists re-ranked with longer calibration runs.
"""
import argparse, itertools, json, math, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t
from exp_revision_capacity import expected_reward, static_feasible, myopic_table, get_actions
from revision_experiments_dp import BASE, solve_vi

def rollout(C,cfg,policy,steps,seed,burnin=500):
    rng=np.random.default_rng(seed)
    nh=nl=0; rs=us=0.; bh=bl=ahsum=alsum=0; near=0; differs=0
    disc=0.; w=1.
    for k in range(steps+burnin):
        ph,pl,qh,ql=policy(nh,nl)
        free=C-cfg['rH']*nh-cfg['rL']*nl
        if cfg['rH']*qh+cfg['rL']*ql>free: raise ValueError('infeasible action')
        ah=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*ph))
        al=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pl))
        yh=min(ah,qh); yl=min(al,ql)
        u=(C-free)/C
        r=ph*yh+pl*yl-cfg['xiH']*(ah-yh)-cfg['xiL']*(al-yl)-cfg['kappa']*u*u
        dh=rng.binomial(nh,cfg['muH']); dl=rng.binomial(nl,cfg['muL'])
        nh=nh-dh+yh; nl=nl-dl+yl
        if k>=burnin:
            rs+=r; us+=u; bh+=ah-yh; bl+=al-yl; ahsum+=ah; alsum+=al
            near+=(free<max(cfg['rH'],cfg['rL'])*cfg['qmaxH'])
            disc+=w*r; w*=cfg['gamma']
    return dict(reward=rs/steps,utilization=us/steps,block_H=bh/max(ahsum,1),
                block_L=bl/max(alsum,1),capacity_pressure=near/steps,
                normalized_discounted=(1-cfg['gamma'])*disc)

def optimize_static(C,cfg,actions,stage1_steps,stage1_seeds,topk,stage2_steps,stage2_seeds,burnin):
    # Different seeds than final policy evaluation; CRN for every candidate.
    scored=[]
    for a in actions:
        pol=lambda nh,nl,a=a:static_feasible(nh,nl,a,C,cfg)
        vals=[rollout(C,cfg,pol,stage1_steps,100000+i,burnin)['reward'] for i in range(stage1_seeds)]
        scored.append((float(np.mean(vals)),a))
    finalists=sorted(scored,reverse=True)[:topk]
    ranked=[]
    for _,a in finalists:
        pol=lambda nh,nl,a=a:static_feasible(nh,nl,a,C,cfg)
        vals=[rollout(C,cfg,pol,stage2_steps,200000+i,burnin)['reward'] for i in range(stage2_seeds)]
        ranked.append((float(np.mean(vals)),a,float(np.std(vals,ddof=1)) if len(vals)>1 else 0.))
    ranked.sort(reverse=True)
    return ranked[0],ranked

def summarize(rows):
    d={}
    for key in ['reward','utilization','block_H','block_L','capacity_pressure','normalized_discounted']:
        v=np.array([r[key] for r in rows]); d[key]=float(v.mean())
        d[key+'_ci95']=float(t.ppf(.975,len(v)-1)*v.std(ddof=1)/np.sqrt(len(v))) if len(v)>1 else None
    return d

def main(args):
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    # Demand multipliers are adjustable. These are calibration candidates, not claimed target regimes.
    multipliers={'light':args.light,'moderate':args.moderate,'heavy':args.heavy}
    all_rows=[]; summary_rows=[]; static_rows=[]
    for scenario,mult in multipliers.items():
        cfg=BASE.copy();cfg.update(lambda0H=BASE['lambda0H']*mult,
            lambda0L=BASE['lambda0L']*mult,qmaxH=args.qmax,qmaxL=args.qmax)
        actions=get_actions(cfg)
        print('Solving',scenario,'multiplier',mult,flush=True)
        sol=solve_vi(args.capacity,cfg,tol=args.tol,max_iter=args.max_iter)
        dp=lambda nh,nl:sol['actions'][int(sol['policy'][nh,nl])]
        mytab=myopic_table(args.capacity,cfg,actions)
        my=lambda nh,nl:mytab[nh,nl]
        best,ranked=optimize_static(args.capacity,cfg,actions,args.stage1_steps,args.stage1_seeds,
            args.topk,args.stage2_steps,args.stage2_seeds,args.burnin)
        for rank,(score,a,sd) in enumerate(ranked,1):
            static_rows.append(dict(scenario=scenario,rank=rank,calibration_reward=score,
                calibration_sd=sd,action=str(a)))
        static=lambda nh,nl:static_feasible(nh,nl,best[1],args.capacity,cfg)
        for name,policy in [('DP',dp),('Myopic',my),('Static',static)]:
            rows=[rollout(args.capacity,cfg,policy,args.steps,300000+i,args.burnin) for i in range(args.seeds)]
            for seed,r in enumerate(rows): all_rows.append(dict(scenario=scenario,policy=name,seed=seed,**r))
            s=summarize(rows)
            summary_rows.append(dict(scenario=scenario,policy=name,C=args.capacity,
                load_multiplier=mult,qmax=args.qmax,static_action=str(best[1]) if name=='Static' else '',
                dp_iterations=sol['iterations'],dp_solve_time_s=sol['solve_time_s'],**s))
            print(scenario,name,'reward',round(s['reward'],3),'util',round(s['utilization'],3),
                  'pressure',round(s['capacity_pressure'],3),flush=True)
    pd.DataFrame(all_rows).to_csv(out/'per_seed.csv',index=False)
    pd.DataFrame(summary_rows).to_csv(out/'summary.csv',index=False)
    pd.DataFrame(static_rows).to_csv(out/'static_finalists.csv',index=False)
    (out/'config.json').write_text(json.dumps(vars(args),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--capacity',type=int,default=12);p.add_argument('--qmax',type=int,default=4)
    p.add_argument('--light',type=float,default=.20);p.add_argument('--moderate',type=float,default=.75)
    p.add_argument('--heavy',type=float,default=1.5)
    p.add_argument('--stage1-steps',type=int,default=600);p.add_argument('--stage1-seeds',type=int,default=3)
    p.add_argument('--topk',type=int,default=8);p.add_argument('--stage2-steps',type=int,default=2500)
    p.add_argument('--stage2-seeds',type=int,default=5);p.add_argument('--burnin',type=int,default=400)
    p.add_argument('--steps',type=int,default=10000);p.add_argument('--seeds',type=int,default=10)
    p.add_argument('--tol',type=float,default=1e-6);p.add_argument('--max-iter',type=int,default=2000)
    p.add_argument('--out',default='capacity_v2_results')
    main(p.parse_args())
