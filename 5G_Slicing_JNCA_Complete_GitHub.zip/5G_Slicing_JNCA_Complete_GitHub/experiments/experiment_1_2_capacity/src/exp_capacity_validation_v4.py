"""C=50 capacity experiment: paired-seed inference and genuine binding diagnostics.
Uses September DP model; static policies selected only on separate calibration streams.
Run: python exp_capacity_validation_v4.py --out results
"""
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t
from revision_experiments_dp import BASE, solve_vi
from exp_revision_capacity import get_actions, myopic_table, static_feasible
from exp_revision_capacity_v3 import optimize_static


def simulate(C,cfg,policy,steps,seed,burnin,unconstrained):
    rng=np.random.default_rng(seed); nh=nl=0
    sums=np.zeros(12,dtype=float); w=1.; disc=0.
    for k in range(steps+burnin):
        free=C-cfg['rH']*nh-cfg['rL']*nl
        a=policy(nh,nl); ph,pl,qh,ql=a
        assert cfg['rH']*qh+cfg['rL']*ql<=free
        ah=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*ph))
        al=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pl))
        yh=min(ah,qh); yl=min(al,ql)
        u=(C-free)/C
        r=ph*yh+pl*yl-cfg['xiH']*(ah-yh)-cfg['xiL']*(al-yl)-cfg['kappa']*u*u
        if k>=burnin:
            # A genuine scarcity diagnostic: unconstrained one-slot optimal quota
            # does not fit remaining capacity. Also record actual full occupancy.
            ua=unconstrained
            wants=cfg['rH']*ua[2]+cfg['rL']*ua[3]
            sums += [r,u,ah-yh,al-yl,ah,al,float(free==0),float(free<wants),
                     float(cfg['rH']*qh+cfg['rL']*ql==free),
                     float(qh<cfg['qmaxH'] or ql<cfg['qmaxL']),
                     float(qh==0),float(ql==0)]
            disc+=w*r;w*=cfg['gamma']
        dh=rng.binomial(nh,cfg['muH']); dl=rng.binomial(nl,cfg['muL'])
        nh=nh-dh+yh;nl=nl-dl+yl
        assert cfg['rH']*nh+cfg['rL']*nl<=C
    return dict(reward=sums[0]/steps,utilization=sums[1]/steps,
        block_H=sums[2]/max(1,sums[4]),block_L=sums[3]/max(1,sums[5]),
        full_occupancy=sums[6]/steps,unconstrained_myopic_infeasible=sums[7]/steps,
        action_fills_free_capacity=sums[8]/steps,below_max_quota=sums[9]/steps,
        zero_H_quota=sums[10]/steps,zero_L_quota=sums[11]/steps,
        normalized_discounted=(1-cfg['gamma'])*disc)

def ci(x):
    x=np.asarray(x,dtype=float);n=len(x)
    return (float(x.mean()),float(t.ppf(.975,n-1)*x.std(ddof=1)/np.sqrt(n))) if n>1 else (float(x.mean()),float('nan'))

def main(a):
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    allrows=[];summ=[];diffs=[];chosen=[]
    for scenario,mult in [('light',a.light),('moderate',a.moderate),('heavy',a.heavy)]:
        if a.scenario != 'all' and scenario != a.scenario: continue
        cfg=BASE.copy();cfg.update(lambda0H=BASE['lambda0H']*mult,lambda0L=BASE['lambda0L']*mult,qmaxH=a.qmax,qmaxL=a.qmax)
        actions=get_actions(cfg)
        print('Solving',scenario,mult,flush=True)
        sol=solve_vi(a.capacity,cfg,tol=a.tol,max_iter=a.max_iter)
        dp=lambda h,l:sol['actions'][int(sol['policy'][h,l])]
        mt=myopic_table(a.capacity,cfg,actions)
        my=lambda h,l:mt[h,l]
        if a.skip_static_tuning:
            # ONLY for smoke testing; not a publication-grade tuned static baseline.
            static_action=(3.,2.25,3,4)
        else:
            best,ranked=optimize_static(a.capacity,cfg,actions,a.stage1_steps,a.stage1_seeds,a.topk,a.stage2_steps,a.stage2_seeds,a.burnin)
            static_action=best[1]
        static=lambda h,l:static_feasible(h,l,static_action,a.capacity,cfg)
        # Unconstrained immediate-reward optimum at a state with enough capacity.
        from exp_revision_capacity import expected_reward
        unconst=max(actions,key=lambda ac:expected_reward(0,0,ac,a.capacity,cfg))
        chosen.append(dict(scenario=scenario,multiplier=mult,static_action=str(static_action),unconstrained_myopic_action=str(unconst),dp_iterations=sol['iterations']))
        for i in range(a.seeds):
            for name,policy in [('DP',dp),('Myopic',my),('Static',static)]:
                r=simulate(a.capacity,cfg,policy,a.steps,400000+i,a.burnin,unconst)
                allrows.append(dict(scenario=scenario,policy=name,seed=i,**r))
        frame=pd.DataFrame([r for r in allrows if r['scenario']==scenario])
        metrics=[c for c in frame if c not in ('scenario','policy','seed')]
        for name,part in frame.groupby('policy'):
            rec=dict(scenario=scenario,policy=name,multiplier=mult,C=a.capacity,qmax=a.qmax)
            for metric in metrics:
                rec[metric],rec[metric+'_ci95']=ci(part[metric])
            summ.append(rec)
        pivot=frame.pivot(index='seed',columns='policy',values='reward')
        for alt in ['Myopic','Static']:
            delta=pivot['DP']-pivot[alt]
            m,h=ci(delta)
            diffs.append(dict(scenario=scenario,comparison='DP minus '+alt,mean_difference=m,ci95_halfwidth=h,ci95_lower=m-h,ci95_upper=m+h,seeds=a.seeds))
        pd.DataFrame(allrows).to_csv(out/'per_seed.csv',index=False)
        pd.DataFrame(summ).to_csv(out/'summary.csv',index=False)
        pd.DataFrame(diffs).to_csv(out/'paired_differences.csv',index=False)
        pd.DataFrame(chosen).to_csv(out/'policy_configurations.csv',index=False)
        print(scenario,[(x['policy'],round(x['reward'],4),round(x['unconstrained_myopic_infeasible'],3)) for x in summ if x['scenario']==scenario],flush=True)
    pd.DataFrame(allrows).to_csv(out/'per_seed.csv',index=False)
    pd.DataFrame(summ).to_csv(out/'summary.csv',index=False)
    pd.DataFrame(diffs).to_csv(out/'paired_differences.csv',index=False)
    pd.DataFrame(chosen).to_csv(out/'policy_configurations.csv',index=False)
    (out/'run_config.json').write_text(json.dumps(vars(a),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--scenario',choices=['all','light','moderate','heavy'],default='all')
    p.add_argument('--capacity',type=int,default=50);p.add_argument('--qmax',type=int,default=4)
    p.add_argument('--light',type=float,default=.5);p.add_argument('--moderate',type=float,default=2.0);p.add_argument('--heavy',type=float,default=5.0)
    p.add_argument('--steps',type=int,default=10000);p.add_argument('--seeds',type=int,default=10);p.add_argument('--burnin',type=int,default=1000)
    p.add_argument('--stage1-steps',type=int,default=1000);p.add_argument('--stage1-seeds',type=int,default=4)
    p.add_argument('--topk',type=int,default=10);p.add_argument('--stage2-steps',type=int,default=5000);p.add_argument('--stage2-seeds',type=int,default=8)
    p.add_argument('--tol',type=float,default=1e-6);p.add_argument('--max-iter',type=int,default=2000)
    p.add_argument('--skip-static-tuning',action='store_true',help='SMOKE TEST ONLY')
    p.add_argument('--out',default='results_v4')
    main(p.parse_args())
