import math, time, json
import numpy as np
import pandas as pd
from scipy.stats import binom, poisson, t
import matplotlib.pyplot as plt

# -----------------------------
# Baseline model configuration
# -----------------------------
BASE = {
    'rH': 2, 'rL': 1,
    'pricesH': (1.0, 2.0, 3.0),
    'pricesL': (0.75, 1.5, 2.25),
    'qmaxH': 2, 'qmaxL': 2,
    'lambda0H': 5.0, 'lambda0L': 7.0,
    'betaH': 0.60, 'betaL': 0.70,
    'muH': 0.25, 'muL': 0.20,
    'gamma': 0.99,
    'kappa': 0.15,
    'xiH': 0.25, 'xiL': 0.15,
}


def y_dist(lam, q):
    if q == 0:
        return np.array([1.0])
    probs = [poisson.pmf(y, lam) for y in range(q)]
    tail = max(0.0, 1.0 - poisson.cdf(q-1, lam))
    return np.array(probs + [tail], dtype=float)


def transition_matrix(maxn, lam, mu, q):
    T = np.zeros((maxn+1, maxn+1), dtype=float)
    py = y_dist(lam, q)
    for n in range(maxn+1):
        pd = binom.pmf(np.arange(n+1), n, mu)
        for d, p_d in enumerate(pd):
            if p_d == 0: continue
            base = n-d
            for y, p_y in enumerate(py):
                nn = base + y
                if nn <= maxn:
                    T[n, nn] += p_d*p_y
        s = T[n].sum()
        if s > 0:
            T[n] /= s
    return T


def g_trunc(lam, q):
    if q <= 0: return 0.0
    return lam*poisson.cdf(q-2, lam) + q*(1-poisson.cdf(q-1, lam))


def build_problem(C, cfg):
    rH, rL = cfg['rH'], cfg['rL']
    maxH, maxL = C//rH, C//rL
    nH = np.arange(maxH+1)[:,None]
    nL = np.arange(maxL+1)[None,:]
    used = rH*nH + rL*nL
    feasible_state = used <= C
    rho = used / C

    keysH=[]; TH={}; metaH={}
    for p in cfg['pricesH']:
        lam=cfg['lambda0H']*math.exp(-cfg['betaH']*p)
        for q in range(cfg['qmaxH']+1):
            k=(p,q); keysH.append(k)
            TH[k]=transition_matrix(maxH,lam,cfg['muH'],q)
            g=g_trunc(lam,q)
            metaH[k]=(lam,g,lam-g)
    keysL=[]; TL={}; metaL={}
    for p in cfg['pricesL']:
        lam=cfg['lambda0L']*math.exp(-cfg['betaL']*p)
        for q in range(cfg['qmaxL']+1):
            k=(p,q); keysL.append(k)
            TL[k]=transition_matrix(maxL,lam,cfg['muL'],q)
            g=g_trunc(lam,q)
            metaL[k]=(lam,g,lam-g)

    return maxH,maxL,used,feasible_state,rho,keysH,keysL,TH,TL,metaH,metaL


def solve_vi(C, cfg, tol=1e-7, max_iter=3000):
    build=build_problem(C,cfg)
    maxH,maxL,used,fs,rho,keysH,keysL,TH,TL,metaH,metaL=build
    V=np.zeros((maxH+1,maxL+1), dtype=float)
    V[~fs]=0.0
    policy=np.full(V.shape,-1,dtype=np.int16)
    actions=[]
    feasibility=[]
    reward_mats=[]
    for kH in keysH:
        pH,qH=kH; lamH,gH,bH=metaH[kH]
        for kL in keysL:
            pL,qL=kL; lamL,gL,bL=metaL[kL]
            idx=len(actions); actions.append((pH,pL,qH,qL))
            free=C-used
            fa = fs & ((cfg['rH']*qH + cfg['rL']*qL) <= free)
            R = pH*gH + pL*gL - cfg['kappa']*(rho**2) - cfg['xiH']*bH - cfg['xiL']*bL
            feasibility.append(fa); reward_mats.append(R)
    t0=time.perf_counter()
    for it in range(1,max_iter+1):
        Vnew=np.full_like(V,-np.inf)
        Pnew=np.full_like(policy,-1)
        idx=0
        for kH in keysH:
            left=TH[kH]
            LV=left @ V
            for kL in keysL:
                cont=LV @ TL[kL].T
                Q=reward_mats[idx] + cfg['gamma']*cont
                mask=feasibility[idx]
                better=mask & (Q>Vnew)
                Vnew[better]=Q[better]
                Pnew[better]=idx
                idx+=1
        Vnew[~fs]=0.0
        diff=np.max(np.abs(Vnew[fs]-V[fs]))
        V=Vnew; policy=Pnew
        if diff<tol:
            break
    elapsed=time.perf_counter()-t0
    nstates=int(fs.sum())
    nsa=int(sum(int(m.sum()) for m in feasibility))
    return {
        'V':V,'policy':policy,'actions':actions,'feasible_state':fs,'used':used,
        'iterations':it,'solve_time_s':elapsed,'nstates':nstates,'n_state_actions':nsa,
        'build':build
    }


def simulate_policy(C,cfg,sol,n_steps=4000,n_rep=20,seed=1234):
    rng_master=np.random.default_rng(seed)
    rows=[]
    maxH,maxL,used,fs,rho,keysH,keysL,TH,TL,metaH,metaL=sol['build']
    actions=sol['actions']; pol=sol['policy']
    for rep in range(n_rep):
        rng=np.random.default_rng(rng_master.integers(0,2**32-1))
        nH=nL=0
        rewards=[]; utils=[]; blocksH=[]; blocksL=[]; admitsH=[]; admitsL=[]; pricesH=[]; pricesL=[]
        arrHtot=arrLtot=0
        for _ in range(n_steps):
            ai=int(pol[nH,nL]); pH,pL,qH,qL=actions[ai]
            lamH=cfg['lambda0H']*math.exp(-cfg['betaH']*pH)
            lamL=cfg['lambda0L']*math.exp(-cfg['betaL']*pL)
            AH=rng.poisson(lamH); AL=rng.poisson(lamL)
            YH=min(AH,qH); YL=min(AL,qL)
            BH=AH-YH; BL=AL-YL
            DH=rng.binomial(nH,cfg['muH']) if nH else 0
            DL=rng.binomial(nL,cfg['muL']) if nL else 0
            util=(cfg['rH']*nH+cfg['rL']*nL)/C
            rew=pH*YH+pL*YL-cfg['kappa']*util**2-cfg['xiH']*BH-cfg['xiL']*BL
            nH=nH-DH+YH; nL=nL-DL+YL
            if cfg['rH']*nH+cfg['rL']*nL>C:
                raise RuntimeError('capacity infeasible')
            rewards.append(rew); utils.append(util); blocksH.append(BH); blocksL.append(BL); admitsH.append(YH); admitsL.append(YL); pricesH.append(pH); pricesL.append(pL)
            arrHtot += AH; arrLtot += AL
        rows.append({
            'rep':rep,'reward':np.mean(rewards),'utilization':np.mean(utils),
            'block_H':sum(blocksH)/max(1,arrHtot),'block_L':sum(blocksL)/max(1,arrLtot),
            'admit_H':np.mean(admitsH),'admit_L':np.mean(admitsL),
            'price_H':np.mean(pricesH),'price_L':np.mean(pricesL)
        })
    return pd.DataFrame(rows)


def mean_ci(x):
    x=np.asarray(x,dtype=float); n=len(x); m=x.mean(); s=x.std(ddof=1)
    h=t.ppf(.975,n-1)*s/math.sqrt(n) if n>1 else 0
    return m,h


def exp1(outdir='/mnt/data'):
    # Three service regimes x three elasticity regimes at C=50.
    mu_pairs=[(0.15,0.12),(0.25,0.20),(0.35,0.30)]
    beta_pairs=[(0.45,0.55),(0.60,0.70),(0.75,0.85)]
    allrows=[]
    for muH,muL in mu_pairs:
        for betaH,betaL in beta_pairs:
            cfg=BASE.copy(); cfg.update(muH=muH,muL=muL,betaH=betaH,betaL=betaL)
            sol=solve_vi(50,cfg,tol=1e-6)
            sim=simulate_policy(50,cfg,sol,n_steps=3000,n_rep=10,seed=1000+int(muH*1000)+int(betaH*1000))
            row={'C':50,'muH':muH,'muL':muL,'betaH':betaH,'betaL':betaL,
                 'states':sol['nstates'],'state_actions':sol['n_state_actions'],'dp_time_s':sol['solve_time_s'],'iterations':sol['iterations']}
            for col in ['reward','utilization','block_H','block_L','admit_H','admit_L','price_H','price_L']:
                m,h=mean_ci(sim[col]); row[col]=m; row[col+'_ci95']=h
            allrows.append(row)
            print('EXP1',muH,muL,betaH,betaL,'reward',row['reward'],'time',row['dp_time_s'])
    df=pd.DataFrame(allrows)
    df.to_csv(f'{outdir}/exp1_two_class_sensitivity.csv',index=False)
    return df


def exp2(outdir='/mnt/data'):
    Cs=[20,50,75,100,150,200]
    rows=[]
    for C in Cs:
        sol=solve_vi(C,BASE,tol=1e-6,max_iter=2500)
        rows.append({'C':C,'states':sol['nstates'],'state_actions':sol['n_state_actions'],
                     'iterations':sol['iterations'],'dp_time_s':sol['solve_time_s'],
                     'V_empty':float(sol['V'][0,0])})
        print('EXP2',rows[-1])
    df=pd.DataFrame(rows)
    df.to_csv(f'{outdir}/exp2_dp_scalability.csv',index=False)
    plt.figure(figsize=(6,4)); plt.plot(df['C'],df['dp_time_s'],marker='o'); plt.xlabel('Shared PRB capacity C'); plt.ylabel('DP solution time (s)'); plt.grid(True,alpha=.3); plt.tight_layout(); plt.savefig(f'{outdir}/exp2_dp_time_vs_capacity.png',dpi=200); plt.close()
    plt.figure(figsize=(6,4)); plt.plot(df['states'],df['dp_time_s'],marker='o'); plt.xlabel('Number of feasible states'); plt.ylabel('DP solution time (s)'); plt.grid(True,alpha=.3); plt.tight_layout(); plt.savefig(f'{outdir}/exp2_dp_time_vs_states.png',dpi=200); plt.close()
    return df

if __name__=='__main__':
    print('BASE',json.dumps(BASE,indent=2))
    d1=exp1(); d2=exp2()
    print('\nEXP1 SUMMARY\n',d1.to_string(index=False))
    print('\nEXP2 SUMMARY\n',d2.to_string(index=False))
