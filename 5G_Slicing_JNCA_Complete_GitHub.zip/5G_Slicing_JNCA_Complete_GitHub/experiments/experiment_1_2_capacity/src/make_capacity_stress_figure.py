import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/mnt/data'); out=root/'c50_policy_audit'
with open(out/'occupancy_policy_audit.csv',newline='') as f: rows=list(csv.DictReader(f))
with open(out/'summary.csv',newline='') as f: summary=list(csv.DictReader(f))
regimes=['light','moderate','heavy']; names=['Light','Moderate','High']
press=[100*float(next(r['unconstrained_myopic_infeasible'] for r in summary if r['scenario']==k and r['policy']=='DP')) for k in regimes]
heavy=[next(r for r in rows if r['scenario']=='heavy' and r['band']==b) for b in ['40-60%','60-80%','80-100%']]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
fig,axs=plt.subplots(1,2,figsize=(10.5,3.9),gridspec_kw={'width_ratios':[0.92,1.08]})
ax=axs[0]; bars=ax.bar(names,press,color=['#8da6bd','#437c9b','#214e70'],width=.58)
ax.set_ylabel('Capacity-pressure frequency (%)');ax.set_ylim(0,66);ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
for b,v in zip(bars,press):ax.text(b.get_x()+b.get_width()/2,v+1.4,f'{v:.1f}%',ha='center',fontsize=10)
ax.set_title('(a) Demand intensity and capacity pressure',fontsize=10.5,pad=11)
ax=axs[1]; x=list(range(3)); h=[float(r['mean_quota_H']) for r in heavy];l=[float(r['mean_quota_L']) for r in heavy]
ax.plot(x,h,'o-',color='#1e567a',lw=2.3,ms=7,label='Premium quota')
ax.plot(x,l,'s--',color='#bd7333',lw=2.1,ms=6,label='Standard quota')
ax.set_xticks(x,['40–60%','60–80%','80–100%']);ax.set_ylim(0,4.45);ax.set_ylabel('Mean selected admission quota');ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
ax.set_title('(b) Quotas by occupancy under high demand',fontsize=10.5,pad=11)
ax.legend(frameon=False,loc='lower left',fontsize=9)
fig.tight_layout(w_pad=2.7)
for ext in ['pdf','png']:
 fig.savefig(root/f'exp_capacity_stress_policy.{ext}',dpi=300,bbox_inches='tight')
plt.close(fig)
tex=(root/'section_6_4_capacity_stress_revised.tex').read_text()
needle='For context, we also evaluate an immediate-reward-maximizing (myopic)'
addition=r'''Figure~\ref{fig:capacity_stress_policy} summarizes the two central
operational findings. Panel (a) shows the increasing frequency of
capacity-constrained admission decisions across the three demand
regimes. Panel (b) shows how the selected admission quotas change with
occupancy in the high-demand regime. The occupancy bands represent
states actually visited by the simulated DP policy; the plotted quota
values are visit-weighted conditional averages, not quota bounds.

\begin{figure}[htbp]
    \centering
    \includegraphics[width=0.98\linewidth]{exp_capacity_stress_policy.pdf}
    \caption{Capacity stress and the response of the DP admission policy
    at $C=50$: (a) frequency at which the unconstrained myopic admission
    choice is infeasible, by demand regime; (b) mean premium and standard
    admission quotas conditional on PRB utilization under high demand.
    The averages in panel (b) are based on visited decision epochs.}
    \label{fig:capacity_stress_policy}
\end{figure}

'''
assert needle in tex
tex=tex.replace(needle,addition+needle)
(root/'section_6_4_capacity_stress_with_figure.tex').write_text(tex)
print('Created figures and revised LaTeX')
