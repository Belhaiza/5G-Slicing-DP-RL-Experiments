import os,sys,json,math
from pathlib import Path
import numpy as np,pandas as pd
sys.path.insert(0,str(Path(__file__).parent/'source'))
from revision_experiments_dp import BASE,solve_vi
from exp_revision_capacity import get_actions,myopic_table
out=Path(__file__).parent
rows=[]
for name,mult in [('heavy',5.)]:
 cfg=BASE.copy();cfg.update(lambda0H=BASE['lambda0H']*mult,lambda0L=BASE['lambda0L']*mult,qmaxH=4,qmaxL=4)
 sol=solve_vi(50,cfg,tol=.005,max_iter=1200)
 pol=sol['policy'];acts=sol['actions']; fs=sol['feasible_state']; my=myopic_table(50,cfg,get_actions(cfg))
 np.savez_compressed(out/f'{name}_dp_policy.npz',policy=pol,actions=np.array(acts),feasible=fs)
 rng=np.random.default_rng(20261022);h=l=0;states=[]
 for k in range(210000):
  a=acts[int(pol[h,l])];ph,pl,qh,ql=a
  ah=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*ph));al=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pl))
  dh=rng.binomial(h,cfg['muH']);dl=rng.binomial(l,cfg['muL'])
  if k>=10000:states.append((h,l))
  h=h-dh+min(ah,qh);l=l-dl+min(al,ql)
 st=np.array(states);visited=np.zeros(pol.shape,dtype=int)
 np.add.at(visited,(st[:,0],st[:,1]),1)
 occupancy=(2*st[:,0]+st[:,1])/50
 dpa=np.array([acts[int(pol[i,j])] for i,j in zip(st[:,0],st[:,1])]);mya=np.array([my[i,j] for i,j in zip(st[:,0],st[:,1])])
 for band,mask in [('0-40%',occupancy<.4),('40-60%',(occupancy>=.4)&(occupancy<.6)),('60-80%',(occupancy>=.6)&(occupancy<.8)),('80-100%',occupancy>=.8),('all',np.ones(len(st),bool))]:
  a=dpa[mask];b=mya[mask];row=dict(scenario=name,band=band,observations=len(a),fraction=len(a)/len(st),distinct_dp_actions=len(set(map(tuple,a))),mean_price_H=a[:,0].mean() if len(a) else None,mean_price_L=a[:,1].mean() if len(a) else None,mean_quota_H=a[:,2].mean() if len(a) else None,mean_quota_L=a[:,3].mean() if len(a) else None,dp_myopic_disagreement=np.mean(np.any(a!=b,axis=1)) if len(a) else None,dp_myopic_price_disagreement=np.mean(np.any(a[:,:2]!=b[:,:2],axis=1)) if len(a) else None,dp_myopic_quota_disagreement=np.mean(np.any(a[:,2:]!=b[:,2:],axis=1)) if len(a) else None)
  rows.append(row)
 print(name,'iterations',sol['iterations'],'distinct visited states',np.count_nonzero(visited),'distinct DP actions',len(set(map(tuple,dpa))),'disagreement',np.mean(np.any(dpa!=mya,axis=1)),flush=True)
 pd.DataFrame(rows).to_csv(out/'occupancy_policy_audit.csv',index=False)
 pd.DataFrame([dict(scenario=name,nH=i,nL=j,visits=int(visited[i,j]),occupancy=(2*i+j)/50,priceH=acts[int(pol[i,j])][0],priceL=acts[int(pol[i,j])][1],quotaH=acts[int(pol[i,j])][2],quotaL=acts[int(pol[i,j])][3],myopic_action=str(my[i,j])) for i,j in zip(*np.where(fs))]).to_csv(out/f'{name}_state_policy.csv',index=False)
