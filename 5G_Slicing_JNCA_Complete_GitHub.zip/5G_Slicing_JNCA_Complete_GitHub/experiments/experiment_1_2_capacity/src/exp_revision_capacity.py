"""Second-round capacity-scarcity study. Uses September baseline DP unmodified.
Policies: discounted DP, immediate-reward myopic, fixed-price/fixed-quota static.
Static quotas are clipped to feasible capacity (premium first), and that
operational convention is explicitly documented. Common evaluation objective:
reward per slot, with discounted return reported separately.
"""
import argparse, itertools, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import t
from revision_experiments_dp import BASE, solve_vi, g_trunc

SCENARIOS = {'light': (5.,7.), 'moderate': (10.,14.), 'heavy': (18.,25.)}

def get_actions(cfg):
    return list(itertools.product(cfg['pricesH'],cfg['pricesL'],range(cfg['qmaxH']+1),range(cfg['qmaxL']+1)))

def expected_reward(nh,nl,a,C,cfg):
    ph,pl,qh,ql=a
    lh=cfg['lambda0H']*math.exp(-cfg['betaH']*ph)
    ll=cfg['lambda0L']*math.exp(-cfg['betaL']*pl)
    gh=g_trunc(lh,qh); gl=g_trunc(ll,ql)
    rho=(cfg['rH']*nh+cfg['rL']*nl)/C
    return ph*gh+pl*gl-cfg['xiH']*(lh-gh)-cfg['xiL']*(ll-gl)-cfg['kappa']*rho*rho

def static_feasible(nh,nl,a,C,cfg):
    ph,pl,qh,ql=a
    free=C-cfg['rH']*nh-cfg['rL']*nl
    # Fixed class priority: H then L. This is one static operational baseline.
    qh=min(qh,free//cfg['rH'])
    ql=min(ql,(free-cfg['rH']*qh)//cfg['rL'])
    return (ph,pl,int(qh),int(ql))

def myopic_table(C,cfg,actions):
    table={}
    for nh in range(C//cfg['rH']+1):
        for nl in range(C//cfg['rL']+1):
            free=C-cfg['rH']*nh-cfg['rL']*nl
            if free<0: continue
            feasible=(a for a in actions if cfg['rH']*a[2]+cfg['rL']*a[3]<=free)
            table[nh,nl]=max(feasible,key=lambda a:expected_reward(nh,nl,a,C,cfg))
    return table

def evaluate(C,cfg,policy,steps,seeds,burnin=1000):
    rows=[]
    for seed in range(seeds):
        rng=np.random.default_rng(12001+seed)
        nh=nl=0; rewards=[]; utilization=[]; blocks=[0,0]; arrivals=[0,0]
        discounted=0.; discount_weight=1.
        for k in range(steps+burnin):
            a=policy(nh,nl)
            ph,pl,qh,ql=a
            free=C-cfg['rH']*nh-cfg['rL']*nl
            assert cfg['rH']*qh+cfg['rL']*ql<=free
            ah=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*ph))
            al=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pl))
            yh=min(ah,qh); yl=min(al,ql)
            bh=ah-yh; bl=al-yl
            u=(cfg['rH']*nh+cfg['rL']*nl)/C
            reward=ph*yh+pl*yl-cfg['kappa']*u*u-cfg['xiH']*bh-cfg['xiL']*bl
            dh=rng.binomial(nh,cfg['muH']); dl=rng.binomial(nl,cfg['muL'])
            nh=nh-dh+yh; nl=nl-dl+yl
            assert cfg['rH']*nh+cfg['rL']*nl<=C
            if k>=burnin:
                rewards.append(reward); utilization.append(u)
                blocks[0]+=bh; blocks[1]+=bl
                arrivals[0]+=ah; arrivals[1]+=al
                discounted+=discount_weight*reward
                discount_weight*=cfg['gamma']
        rows.append(dict(seed=seed,reward=np.mean(rewards),utilization=np.mean(utilization),
                         block_H=blocks[0]/max(arrivals[0],1),block_L=blocks[1]/max(arrivals[1],1),
                         normalized_discounted=(1-cfg['gamma'])*discounted))
    return pd.DataFrame(rows)

def summary(df):
    out={}
    for col in ['reward','utilization','block_H','block_L','normalized_discounted']:
        vals=df[col].to_numpy(); out[col]=float(vals.mean());
        out[col+'_ci95']=float(t.ppf(.975,len(vals)-1)*vals.std(ddof=1)/np.sqrt(len(vals))) if len(vals)>1 else None
    return out

def run(args):
    output=Path(args.out); output.mkdir(parents=True,exist_ok=True)
    allrows=[]; summaries=[]
    for scenario,(h,l) in SCENARIOS.items():
        cfg=BASE.copy(); cfg.update(lambda0H=h,lambda0L=l,qmaxH=args.qmax,qmaxL=args.qmax)
        actions=get_actions(cfg)
        sol=solve_vi(args.capacity,cfg,tol=args.tol,max_iter=args.max_iter)
        dp=lambda nh,nl:sol['actions'][int(sol['policy'][nh,nl])]
        mt=myopic_table(args.capacity,cfg,actions)
        my=lambda nh,nl:mt[nh,nl]
        # Static candidate selection by independent evaluation, not on test seeds.
        # Exhaustive action grid, with configurable short calibration trajectories.
        static_scores=[]
        for a in actions:
            static=lambda nh,nl,a=a:static_feasible(nh,nl,a,args.capacity,cfg)
            cal=evaluate(args.capacity,cfg,static,args.calibration_steps,1,burnin=args.burnin)
            static_scores.append((float(cal.reward.iloc[0]),a))
        static_best=max(static_scores,key=lambda v:v[0])[1]
        policies={'DP':dp,'Myopic':my,'Static':lambda nh,nl:static_feasible(nh,nl,static_best,args.capacity,cfg)}
        for name,pol in policies.items():
            df=evaluate(args.capacity,cfg,pol,args.steps,args.seeds,burnin=args.burnin)
            df.insert(0,'policy',name); df.insert(0,'scenario',scenario)
            allrows.append(df)
            row=dict(scenario=scenario,policy=name,C=args.capacity,lambda0H=h,lambda0L=l,
                     qmax=args.qmax,static_action=str(static_best) if name=='Static' else '',
                     dp_iterations=sol['iterations'],dp_solve_time=sol['solve_time_s'])
            row.update(summary(df)); summaries.append(row)
            print(scenario,name,'reward',round(row['reward'],4),'util',round(row['utilization'],4),flush=True)
    pd.concat(allrows,ignore_index=True).to_csv(output/'capacity_scenarios_per_seed.csv',index=False)
    pd.DataFrame(summaries).to_csv(output/'capacity_scenarios_summary.csv',index=False)
    (output/'run_config.json').write_text(json.dumps(vars(args),indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--capacity',type=int,default=20)
    p.add_argument('--qmax',type=int,default=4)
    p.add_argument('--steps',type=int,default=4000)
    p.add_argument('--seeds',type=int,default=10)
    p.add_argument('--calibration-steps',type=int,default=800)
    p.add_argument('--burnin',type=int,default=500)
    p.add_argument('--tol',type=float,default=1e-6)
    p.add_argument('--max-iter',type=int,default=2500)
    p.add_argument('--out',default='results_capacity')
    run(p.parse_args())
