Experiment 5: congestion-penalty stress tests

Run: python stress_test.py
Dependencies: numpy pandas scipy matplotlib

Scenarios:
- C=12, original demand
- C=20, lambda0H and lambda0L multiplied by 1.7
- optimize exact discounted DP separately at kappa=0.15 and kappa=0
- simulate 12 common random seeds, 500 burn-in + 2500 measured slots
- evaluate both under common kappa=0.15 reward

Outputs:
- stress_replications.csv: raw per-replication metrics
- stress_summary.csv: grouped means and standard deviations
- stress_solver.csv: DP solution diagnostics
- stress_findings.tex: proposed manuscript paragraph and table

Interpretation: little or no policy effect in these two scenarios. These are simulation means, not guarantees of equivalence. Matched random seeds do not ensure identical arrival samples if policies select different prices.
