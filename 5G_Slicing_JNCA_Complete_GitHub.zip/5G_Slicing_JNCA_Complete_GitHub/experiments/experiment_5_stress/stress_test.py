import os,sys,time,math
import numpy as np,pandas as pd
sys.path.insert(0,os.path.dirname(__file__))
from revision_experiments_dp import BASE,solve_vi
OUT=os.path.dirname(__file__)

def evaluate(C,cfg,sol,seeds,steps=2500,burn=500):
 rows=[]
 for rep,seed in enumerate(seeds):
  rng=np.random.default_rng(int(seed)); nH=nL=0
  total=np.zeros(11)
  for t in range(steps+burn):
   pH,pL,qH,qL=sol['actions'][int(sol['policy'][nH,nL])]
   AH=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*pH));AL=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pL))
   YH=min(AH,qH);YL=min(AL,qL);BH=AH-YH;BL=AL-YL
   rho=(2*nH+nL)/C
   DH=rng.binomial(nH,cfg['muH']);DL=rng.binomial(nL,cfg['muL'])
   nH=nH-DH+YH;nL=nL-DL+YL
   if 2*nH+nL>C: raise RuntimeError('infeasible')
   if t>=burn: total+=np.array([pH*YH+pL*YL, BH,BL,AH,AL,rho,rho*rho,YH,YL,pH,pL])
  rev,BH,BL,AH,AL,rho,rho2,YH,YL,pH,pL=total
  rows.append(dict(rep=rep,gross_revenue=rev/steps,common_reward=(rev-.15*rho2-cfg['xiH']*BH-cfg['xiL']*BL)/steps,utilization=rho/steps,block_H=BH/AH,block_L=BL/AL,admit_H=YH/steps,admit_L=YL/steps,price_H=pH/steps,price_L=pL/steps))
 return rows

if __name__=='__main__':
 seeds=np.random.default_rng(20261024).integers(1,2**31,size=12)
 rows=[]; stats=[]
 scenarios=[('tight_capacity',12,1.0),('high_demand',20,1.7)]
 for name,C,mult in scenarios:
  for k in (.15,0.):
   cfg=dict(BASE,kappa=k,lambda0H=BASE['lambda0H']*mult,lambda0L=BASE['lambda0L']*mult)
   start=time.time();sol=solve_vi(C,cfg,tol=1e-6,max_iter=2000)
   print('SOLVED',name,C,k,'sec',round(time.time()-start,2),flush=True)
   rr=evaluate(C,cfg,sol,seeds)
   for r in rr: rows.append(dict(scenario=name,C=C,demand_multiplier=mult,kappa_policy=k,**r))
   stats.append(dict(scenario=name,C=C,demand_multiplier=mult,kappa_policy=k,iterations=sol['iterations'],solve_seconds=sol['solve_time_s'],V_empty=sol['V'][0,0]))
   pd.DataFrame(rows).to_csv(OUT+'/stress_replications.csv',index=False)
  df=pd.DataFrame(rows); print(df[df.scenario==name].groupby('kappa_policy')[['common_reward','gross_revenue','utilization','block_H','block_L']].mean(),flush=True)
 pd.DataFrame(stats).to_csv(OUT+'/stress_solver.csv',index=False)
 df=pd.DataFrame(rows)
 sm=df.groupby(['scenario','C','demand_multiplier','kappa_policy'],as_index=False).agg({m:['mean','std'] for m in ['common_reward','gross_revenue','utilization','block_H','block_L','admit_H','admit_L','price_H','price_L']})
 sm.columns=['_'.join(map(str,c)).strip('_') for c in sm.columns]
 sm.to_csv(OUT+'/stress_summary.csv',index=False)
 print('COMPLETE',flush=True)
