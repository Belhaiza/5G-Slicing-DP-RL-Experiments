# Experiment 5: congestion-penalty ablation

Exact discounted value iteration with kappa=0.15 vs 0 at C=20,30,50.

- `run.py`: initial simulation and policy solve.
- `common_evaluation.py`: **preferred** comparison, reevaluates both policies with identical kappa=0.15 reward, separately records gross revenue and blocking. Uses 12 x 3000-slot simulation runs per configuration.
- `common_replications.csv`, `common_summary.csv`: reproducible simulation results.
- `section_ablation.tex`: proposed blue manuscript subsection and table.

Run in an environment with numpy, pandas, scipy, matplotlib: `python common_evaluation.py`. The scripts currently import the baseline DP implementation from `/mnt/data/revision_experiments_dp.py` and are therefore a research archive, not yet a portable GitHub release. The package also includes a local copy of that source for inspection. Adjust the import path to use the local source before publishing.

**Caveats:** finite-horizon sample averages are distinct from discounted DP objectives; using matching RNG seeds is not exact common-random-number coupling when policies induce different Poisson parameters; no formal significance test is claimed.
