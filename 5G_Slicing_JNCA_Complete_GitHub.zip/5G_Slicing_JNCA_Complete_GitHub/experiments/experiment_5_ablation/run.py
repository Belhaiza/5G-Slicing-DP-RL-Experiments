import sys,os,time
sys.path.insert(0,'/mnt/data')
from revision_experiments_dp import BASE,solve_vi,simulate_policy
import pandas as pd,numpy as np
out='/mnt/data/exp5_ablation'; rows=[]; trajectories=[]
for C in (20,30,50):
 for k in (0.15,0.0):
  cfg=dict(BASE,kappa=k); print('SOLVE',C,k,flush=True)
  sol=solve_vi(C,cfg,tol=1e-6,max_iter=2000)
  sim=simulate_policy(C,cfg,sol,n_steps=3000,n_rep=12,seed=20261024+C)
  sim['C']=C;sim['kappa_policy']=k
  # Gross revenue is not directly in the existing simulator: compute via deterministic policy expected rewards in separate evaluation later.
  trajectories.append(sim)
  row={'C':C,'kappa_policy':k,'solve_time_s':sol['solve_time_s'],'iterations':sol['iterations'],'discounted_value_empty':sol['V'][0,0]}
  for metric in ['reward','utilization','block_H','block_L','admit_H','admit_L','price_H','price_L']:
   row[metric]=sim[metric].mean();row[metric+'_sd']=sim[metric].std(ddof=1)
  rows.append(row)
  pd.DataFrame(rows).to_csv(out+'/summary_partial.csv',index=False)
  pd.concat(trajectories).to_csv(out+'/replications_partial.csv',index=False)
  print('DONE',row,flush=True)
pd.DataFrame(rows).to_csv(out+'/summary.csv',index=False)
pd.concat(trajectories).to_csv(out+'/replications.csv',index=False)
