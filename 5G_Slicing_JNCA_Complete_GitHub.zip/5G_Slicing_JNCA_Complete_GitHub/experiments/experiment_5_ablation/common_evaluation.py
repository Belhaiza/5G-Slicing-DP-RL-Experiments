import sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
import numpy as np,pandas as pd
from revision_experiments_dp import BASE,solve_vi
rows=[]
for C in [20,30,50]:
 for k in [.15,0.]:
  cfg=dict(BASE,kappa=k); sol=solve_vi(C,cfg,tol=1e-6,max_iter=2000)
  for rep in range(12):
   rng=np.random.default_rng(20261024+C+rep); nH=nL=0
   vals=np.zeros(9); AHtotal=ALtotal=0
   for t in range(3000):
    pH,pL,qH,qL=sol['actions'][int(sol['policy'][nH,nL])]
    AH=rng.poisson(cfg['lambda0H']*math.exp(-cfg['betaH']*pH));AL=rng.poisson(cfg['lambda0L']*math.exp(-cfg['betaL']*pL))
    YH=min(AH,qH);YL=min(AL,qL);BH=AH-YH;BL=AL-YL
    rho=(2*nH+nL)/C; revenue=pH*YH+pL*YL; penalty=.25*BH+.15*BL
    vals+=np.array([revenue,revenue-penalty-.15*rho*rho,rho*rho,rho,BH,BL,YH,YL,penalty])
    AHtotal+=AH;ALtotal+=AL
    nH-=rng.binomial(nH,.25);nL-=rng.binomial(nL,.20);nH+=YH;nL+=YL
    assert 2*nH+nL<=C
   vals/=3000
   rows.append(dict(C=C,kappa_policy=k,rep=rep,gross_revenue=vals[0],common_reward_k015=vals[1],mean_rho2=vals[2],utilization=vals[3],block_H=vals[4]*3000/AHtotal,block_L=vals[5]*3000/ALtotal,admit_H=vals[6],admit_L=vals[7],blocking_penalty=vals[8]))
df=pd.DataFrame(rows);df.to_csv(str(Path(__file__).resolve().parent / 'common_replications.csv'),index=False)
s=df.groupby(['C','kappa_policy']).agg(['mean','std']);s.to_csv(str(Path(__file__).resolve().parent / 'common_summary.csv'))
print(df.groupby(['C','kappa_policy'])[['gross_revenue','common_reward_k015','mean_rho2','utilization','block_H','block_L']].mean().round(5).to_string())
