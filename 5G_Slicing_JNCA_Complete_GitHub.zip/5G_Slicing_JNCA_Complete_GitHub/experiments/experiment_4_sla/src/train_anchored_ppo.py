"""Primal-dual PPO with separate reward/cost critics and independent dual updates.
The constraint is E[B_H-delta*A_H] <= 0 per slot; policies are evaluated separately.
"""
import argparse, csv, random, time, copy
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.distributions import Categorical
from revision_experiments_rl_exp3 import TwoClassEnv, BASE, evaluate_policy

class Network(nn.Module):
    def __init__(self, n_actions, width=64):
        super().__init__()
        self.body=nn.Sequential(nn.Linear(2,width),nn.Tanh(),nn.Linear(width,width),nn.Tanh())
        self.actor=nn.Linear(width,n_actions)
        self.vreward=nn.Linear(width,1)
        self.vcost=nn.Linear(width,1)
    def forward(self,x):
        z=self.body(x)
        return self.actor(z),self.vreward(z).squeeze(-1),self.vcost(z).squeeze(-1)

def gae(rewards,values,last,gamma=.99,lam=.95):
    adv=np.empty(len(rewards),np.float32); acc=0.
    for k in range(len(rewards)-1,-1,-1):
        nxt=last if k==len(rewards)-1 else values[k+1]
        acc=float(rewards[k])+gamma*float(nxt)-float(values[k])+gamma*lam*acc
        adv[k]=acc
    return adv,adv+values

def train(C=20,delta=.10,seed=0,steps=12000,rollout=512,epochs=4,
          dual_lr=.5,dual_max=50.,dual_ema=.8,lr=3e-4,
          entropy=.015,device='cpu',warm_start=None,anchor_weight=3.0):
    torch.set_num_threads(1)
    np.random.seed(seed); random.seed(seed); torch.manual_seed(seed)
    cfg=BASE.copy(); env=TwoClassEnv(C,cfg,seed=seed)
    model=Network(len(env.actions)).to(device)
    if warm_start is not None: model.load_state_dict(torch.load(warm_start,map_location=device,weights_only=True))
    anchor=copy.deepcopy(model).eval() if warm_start is not None else None
    opt=torch.optim.Adam(model.parameters(),lr=lr)
    obs=env.reset(); multiplier=0.; ema_cost=None; rows=[]; tic=time.perf_counter(); completed=0
    while completed<steps:
        ob=[]; actions=[]; oldlog=[]; masks=[]; rews=[]; costs=[]; vr=[]; vc=[]
        arrivals=blocked=0.
        for _ in range(min(rollout,steps-completed)):
            mask=env.feasible_mask()
            with torch.no_grad():
                logits,rval,cval=model(torch.as_tensor(obs,device=device).unsqueeze(0))
                logits=logits.masked_fill(~torch.as_tensor(mask,device=device).unsqueeze(0),-1e9)
                dist=Categorical(logits=logits); a=dist.sample()
            nextobs,reward,_,info=env.step(int(a.item()))
            cost=float(info['block_H']-delta*info['arr_H'])
            ob.append(obs.copy()); actions.append(int(a.item())); oldlog.append(float(dist.log_prob(a).item()))
            masks.append(mask.copy()); rews.append(reward); costs.append(cost)
            vr.append(float(rval.item())); vc.append(float(cval.item()))
            blocked+=info['block_H']; arrivals+=info['arr_H']; obs=nextobs
        completed+=len(rews)
        with torch.no_grad():
            _,last_r,last_c=model(torch.as_tensor(obs,device=device).unsqueeze(0))
        ra,rt=gae(np.array(rews,np.float32),np.array(vr,np.float32),last_r.item(),cfg['gamma'])
        ca,ct=gae(np.array(costs,np.float32),np.array(vc,np.float32),last_c.item(),cfg['gamma'])
        # Two independently fitted critics; actor receives advantage of r - lambda*c.
        advantage=ra-multiplier*ca
        advantage=(advantage-advantage.mean())/(advantage.std()+1e-8)
        X=torch.tensor(np.stack(ob),dtype=torch.float32,device=device)
        A=torch.tensor(actions,dtype=torch.long,device=device)
        OL=torch.tensor(oldlog,dtype=torch.float32,device=device)
        Mask=torch.tensor(np.stack(masks),dtype=torch.bool,device=device)
        Adv=torch.tensor(advantage,dtype=torch.float32,device=device)
        RT=torch.tensor(rt,dtype=torch.float32,device=device)
        CT=torch.tensor(ct,dtype=torch.float32,device=device)
        for _ in range(epochs):
            for b in torch.randperm(len(actions),device=device).split(64):
                logits,v_r,v_c=model(X[b]); logits=logits.masked_fill(~Mask[b],-1e9)
                dist=Categorical(logits=logits); ratio=(dist.log_prob(A[b])-OL[b]).exp()
                actor=-torch.minimum(ratio*Adv[b],ratio.clamp(.8,1.2)*Adv[b]).mean()
                loss=actor+.5*((v_r-RT[b])**2).mean()+.5*((v_c-CT[b])**2).mean()-entropy*dist.entropy().mean()
                if anchor is not None:
                    with torch.no_grad():
                        al,_,_=anchor(X[b]); target=torch.softmax(al.masked_fill(~Mask[b],-1e9),-1)
                    # Penalize departure from the LP-distilled stochastic policy.
                    loss=loss+anchor_weight*torch.sum(target*(torch.log(target.clamp_min(1e-12))-torch.log_softmax(logits,-1)),dim=-1).mean()
                opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
        # Rollout cost is measured under the OLD policy; update dual only after PPO update.
        cost_per_slot=float(np.mean(costs))
        ema_cost=cost_per_slot if ema_cost is None else dual_ema*ema_cost+(1-dual_ema)*cost_per_slot
        multiplier=float(np.clip(multiplier+dual_lr*ema_cost,0.,dual_max))
        rows.append(dict(step=completed,lambda_value=multiplier,block_rate=blocked/max(1.,arrivals),
                         cost_per_slot=cost_per_slot,cost_ema=ema_cost,mean_reward=np.mean(rews)))
    def policy(obs,mask,env2):
        with torch.no_grad():
            logits,_,_=model(torch.as_tensor(obs,device=device).unsqueeze(0))
            logits=logits.masked_fill(~torch.as_tensor(mask,device=device).unsqueeze(0),-1e9)
            return int(logits.argmax(dim=1).item())
    return model,policy,rows,time.perf_counter()-tic

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--capacities',type=int,nargs='+',default=[20])
    p.add_argument('--deltas',type=float,nargs='+',default=[.2,.15,.1])
    p.add_argument('--seeds',type=int,default=1)
    p.add_argument('--steps',type=int,default=12000)
    p.add_argument('--eval-steps',type=int,default=5000)
    p.add_argument('--outdir',default='results_v2')
    a=p.parse_args(); dest=Path(a.outdir);dest.mkdir(parents=True,exist_ok=True)
    results=[]; traces=[]
    for C in a.capacities:
        for delta in a.deltas:
            for seed in range(a.seeds):
                model,policy,curve,seconds=train(C=C,delta=delta,seed=seed,steps=a.steps)
                ev=evaluate_policy(C,BASE,policy,[200000+seed],n_steps=a.eval_steps).iloc[0].to_dict()
                results.append(dict(C=C,delta=delta,seconds=seconds,lambda_final=curve[-1]['lambda_value'],
                                    violation=max(0.,ev['block_H']-delta),**ev))
                traces.extend(dict(C=C,delta=delta,seed=seed,**r) for r in curve)
                print('C',C,'delta',delta,'seed',seed,'reward',round(ev['reward'],3),'block',round(ev['block_H'],4),'lambda',round(curve[-1]['lambda_value'],3),flush=True)
    for filename,records in [('summary_per_seed.csv',results),('training_trace.csv',traces)]:
        with (dest/filename).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
if __name__=='__main__': main()
