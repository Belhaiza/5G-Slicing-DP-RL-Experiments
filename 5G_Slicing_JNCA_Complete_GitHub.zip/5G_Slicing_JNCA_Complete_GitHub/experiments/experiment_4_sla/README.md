# Experiment 4 — premium-slice SLA constrained control

Reproducibility materials for Section 6.6 of the revised JNCA manuscript. This repository contains the two-class 5G-slicing environment, discounted CMDP LP benchmark, **CMDP-guided anchored PPO**, saved checkpoints, and observed evaluation trajectories.

## Experimental setting

- Capacity `C=20` for neural policy validation; exact LP benchmarks at `C=20` and `C=30`.
- Premium-class SLA: expected premium blocking fraction at most **10%**.
- The warm-start policy is distilled from an exact discounted CMDP solved with an **8% internal target**; PPO is trained with the 10% cost threshold and anchor strength 20.
- Three training seeds (0, 1, 2), 4096 environment interactions per seed.
- Five evaluation seeds (91001–91005), 1000 burn-in and 10000 measured slots each, stochastic masked policy sampling.

## Setup

Python 3.10+ recommended. From repository root:

```bash
python -m venv .venv
# Activate the environment using your operating system's usual command.
pip install -r requirements.txt
```

## Reproduce the reported validation (using saved checkpoints)

```bash
python scripts/validate.py
python scripts/plot.py
```

This writes `results/recomputed_evaluation.csv` and `figures/fig_sla_validation_reproduced.pdf`. The archived original observations are `results/evaluation_fast.csv`.

## Retrain the anchored policy

```bash
python scripts/train.py --steps 4096 --seeds 0 1 2
```

Retrained checkpoints are written under `results/retrained/`. The included `distilled_8.pt` checkpoint is the fixed starting policy used in the reported validation. Retraining the 8% distilled checkpoint from the LP is a separate, more expensive workflow and is **not** included in the single-command reproduction script. The LP solver itself is included:

```bash
python scripts/solve_cmdp.py --capacity 20 --deltas 0.10 0.08
python scripts/solve_cmdp.py --capacity 30 --deltas 0.20 0.15 0.10
```

## Archived results

`results/evaluation_fast.csv` contains five evaluations of the distilled initialization and 15 evaluations of anchored PPO. The 15 PPO evaluations have mean premium blocking **8.5579%**, sample SD **0.2616 percentage points**, and mean realized reward **3.7783 per slot**. No evaluated trajectory exceeded 10%. The same five environment seeds were reused for each training seed, so these are not 15 wholly independent environment random streams.

## Scientific limitations

1. This is **not a model-free PPO baseline**: initialization uses an exact CMDP solution.
2. The exact CMDP solves a **discounted expected-flow constraint**; the reported neural-policy evaluations use **finite-horizon simulated time averages**. Their reward figures are not directly identical performance measures.
3. Zero observed violations in 15 trials is **not** a mathematical guarantee of SLA compliance.
4. Neural-policy validation is limited to `C=20` and the 10% external SLA. Exact LP benchmarks at `C=30` do not imply PPO validation at that capacity.
5. The initial 8% CMDP policy is a supplied checkpoint. Reconstructing its distillation process requires the additional development script and numerical configuration from the research archive.

## Repository map

- `src/`: original simulator, DP model, CMDP solver, anchored PPO trainer.
- `scripts/validate.py`: independent stochastic evaluation of saved checkpoints.
- `scripts/train.py`: three-seed anchored PPO retraining.
- `scripts/solve_cmdp.py`: exact discounted CMDP LP benchmarks.
- `scripts/plot.py`: regenerate an SLA compliance plot.
- `results/`: archived validation and training traces; saved checkpoints.
- `figures/`: manuscript SLA validation figures.
- `section_6_6_updated.tex`: corresponding manuscript subsection.

## Publication

Please add the paper citation and choose an open-source license before making the repository public. The license is intentionally left unassigned rather than guessing the authors' preference.
