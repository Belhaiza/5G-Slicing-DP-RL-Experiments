"""Re-evaluate saved stochastic policies using the original environment simulator."""
import argparse, csv, sys
from pathlib import Path
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from train_anchored_ppo import Network
from revision_experiments_rl_exp3 import TwoClassEnv,BASE

def evaluate(model,seed,steps=10000,burnin=1000):
    env=TwoClassEnv(20,BASE,seed=seed); env.reset()
    hmax,lmax=env.maxH,env.maxL
    states=np.asarray([[h/hmax,l/lmax] for h in range(hmax+1) for l in range(lmax+1)],dtype=np.float32)
    with torch.no_grad(): logits=model(torch.from_numpy(states))[0].numpy()
    actions=np.asarray(env.actions)
    used=np.asarray([2*h+l for h in range(hmax+1) for l in range(lmax+1)])
    feasible=(2*actions[:,2]+actions[:,3])[None,:] <= (20-used)[:,None]
    logits=np.where(feasible,logits,-1e9)
    probs=np.exp(logits-logits.max(axis=1,keepdims=True)); probs/=probs.sum(axis=1,keepdims=True)
    cdf=np.cumsum(probs,axis=1)
    rng=np.random.default_rng(seed+100000)
    reward=blocked=arrivals=0.
    for t in range(steps+burnin):
        state=env.nH*(lmax+1)+env.nL
        a=int(np.searchsorted(cdf[state],rng.random(),side='right'))
        _,r,_,info=env.step(a)
        if t>=burnin:
            reward+=r; blocked+=info['block_H']; arrivals+=info['arr_H']
    return dict(reward=reward/steps,blocking=blocked/arrivals,cost=(blocked-.10*arrivals)/steps)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--steps',type=int,default=10000)
    ap.add_argument('--burnin',type=int,default=1000)
    ap.add_argument('--seeds',type=int,nargs='+',default=[91001,91002,91003,91004,91005])
    ap.add_argument('--train-seeds',type=int,nargs='+',default=[0,1,2])
    ap.add_argument('--output',default=str(ROOT/'results'/'recomputed_evaluation.csv'))
    args=ap.parse_args()
    torch.set_num_threads(1)
    rows=[]
    for train_seed in args.train_seeds:
        model=Network(len(TwoClassEnv(20,BASE).actions))
        path=ROOT/'results'/'checkpoints'/f'anchored_seed{train_seed}.pt'
        model.load_state_dict(torch.load(path,map_location='cpu',weights_only=True)); model.eval()
        for seed in args.seeds:
            row=dict(phase='anchored',train_seed=train_seed,eval_seed=seed,**evaluate(model,seed,args.steps,args.burnin))
            rows.append(row); print(row,flush=True)
    dest=Path(args.output);dest.parent.mkdir(parents=True,exist_ok=True)
    with dest.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    rates=np.array([r['blocking'] for r in rows]);rewards=np.array([r['reward'] for r in rows])
    print(f'count={len(rows)} blocking_mean={rates.mean():.8f} blocking_sd={(rates.std(ddof=1) if len(rates)>1 else 0.):.8f} violations={sum(rates>.10)} reward_mean={rewards.mean():.8f}')
if __name__=='__main__':main()
