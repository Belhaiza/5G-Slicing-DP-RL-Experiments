"""Retrain the published three-seed CMDP-guided anchored PPO experiment."""
import argparse,sys,csv
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from train_anchored_ppo import train

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--steps',type=int,default=4096)
    p.add_argument('--seeds',type=int,nargs='+',default=[0,1,2])
    p.add_argument('--anchor-weight',type=float,default=20.)
    p.add_argument('--outdir',default=str(ROOT/'results'/'retrained'))
    a=p.parse_args(); dest=Path(a.outdir);dest.mkdir(parents=True,exist_ok=True)
    rows=[]
    for seed in a.seeds:
        model,_,trace,seconds=train(C=20,delta=.10,seed=seed,steps=a.steps,warm_start=str(ROOT/'results'/'checkpoints'/'distilled_8.pt'),dual_lr=1.5,entropy=.005,anchor_weight=a.anchor_weight)
        torch.save(model.state_dict(),dest/f'anchored_seed{seed}.pt')
        rows.extend(dict(train_seed=seed,**r) for r in trace)
        print('trained seed',seed,'seconds',seconds,flush=True)
    with (dest/'training_trace.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if __name__=='__main__':main()
