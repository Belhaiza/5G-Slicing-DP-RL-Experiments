"""Plot all saved anchored PPO validation runs; no data is synthesized."""
import argparse,csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--input',default=str(ROOT/'results'/'evaluation_fast.csv'));p.add_argument('--output',default=str(ROOT/'figures'/'fig_sla_validation_reproduced.pdf'))
a=p.parse_args()
rows=[r for r in csv.DictReader(open(a.input)) if r['phase']=='anchored']
rows.sort(key=lambda r:(int(r['train_seed']),int(r['eval_seed'])))
fig,ax=plt.subplots(figsize=(7.5,3.5))
for seed in sorted({int(r['train_seed']) for r in rows}):
    subset=[(i,100*float(r['blocking'])) for i,r in enumerate(rows) if int(r['train_seed'])==seed]
    ax.scatter([x for x,y in subset],[y for x,y in subset],s=35,label=f'Training seed {seed}')
ax.axhline(10,color='black',linestyle='--',linewidth=1,label='10% SLA')
ax.set(xlabel='Evaluation index (grouped by training seed)',ylabel='Premium blocking (%)',ylim=(0,11),xticks=range(len(rows)))
ax.legend(fontsize=8,ncol=2);fig.tight_layout()
Path(a.output).parent.mkdir(parents=True,exist_ok=True);fig.savefig(a.output);plt.close(fig)
