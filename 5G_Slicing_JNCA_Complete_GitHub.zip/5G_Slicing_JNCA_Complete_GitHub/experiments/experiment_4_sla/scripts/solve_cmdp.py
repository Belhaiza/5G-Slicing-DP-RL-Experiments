"""Solve exact discounted CMDP benchmark for capacity 20 or 30."""
import argparse,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from exp4_sparse_cmdp import solve
p=argparse.ArgumentParser();p.add_argument('--capacity',type=int,default=20);p.add_argument('--deltas',type=float,nargs='+',default=[.10,.08]);p.add_argument('--output',default=None)
a=p.parse_args()
rows=solve(a.capacity,a.deltas)
if a.output:Path(a.output).write_text(json.dumps(rows,indent=2))
