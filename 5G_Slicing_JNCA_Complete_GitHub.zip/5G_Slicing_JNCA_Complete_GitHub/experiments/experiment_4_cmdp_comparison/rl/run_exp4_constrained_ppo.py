import math, time, random, importlib.util
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import t
import torch
import torch.nn as nn
import torch.optim as optim

# Load common environment / PPO implementation from Experiment 3
spec=importlib.util.spec_from_file_location('exp3',str(Path(__file__).resolve().parent / 'revision_experiments_rl_exp3.py'))
exp3=importlib.util.module_from_spec(spec); spec.loader.exec_module(exp3)
BASE=exp3.BASE.copy()
TwoClassEnv=exp3.TwoClassEnv
ActorCritic=exp3.ActorCritic
masked_dist=exp3.masked_dist
mean_ci=exp3.mean_ci
evaluate_policy=exp3.evaluate_policy
train_ppo=exp3.train_ppo

# Constraint cost: E[B_H - delta A_H] <= 0, equivalent in long-run ratio to blocking_H <= delta.
def train_lagrangian_ppo(C,cfg,delta=0.15,seed=0,steps=12000,rollout=512,epochs=4,
                         lambda_lr=0.08,lambda_init=0.0,lambda_max=20.0):
    torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
    env=TwoClassEnv(C,cfg,seed=seed); nA=len(env.actions)
    ac=ActorCritic(nA); opt=optim.Adam(ac.parameters(),lr=3e-4)
    obs=env.reset(); done_steps=0; curve=[]; rolling_r=[]; rolling_b=[]; rolling_a=[]
    lag=float(lambda_init); t0=time.perf_counter()

    while done_steps<steps:
        O=[]; A=[]; R=[]; Cst=[]; LP=[]; V=[]; M=[]
        roll_B=0.0; roll_A=0.0
        for _ in range(min(rollout,steps-done_steps)):
            mask_np=env.feasible_mask(); mask=torch.tensor(mask_np,dtype=torch.bool).unsqueeze(0)
            ot=torch.tensor(obs,dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                logits,val=ac(ot); dist=masked_dist(logits,mask); act=dist.sample(); lp=dist.log_prob(act)
            nobs,r,_,info=env.step(int(act.item()))
            cost=float(info['block_H'] - delta*info['arr_H'])
            O.append(obs.copy()); A.append(int(act.item())); R.append(float(r)); Cst.append(cost)
            LP.append(float(lp.item())); V.append(float(val.item())); M.append(mask_np.copy())
            obs=nobs; done_steps+=1
            rolling_r.append(r); rolling_b.append(info['block_H']); rolling_a.append(info['arr_H'])
            rolling_r=rolling_r[-500:]; rolling_b=rolling_b[-500:]; rolling_a=rolling_a[-500:]
            roll_B += info['block_H']; roll_A += info['arr_H']
            if done_steps%500==0:
                br=(sum(rolling_b)/max(1.0,sum(rolling_a)))
                curve.append((done_steps,float(np.mean(rolling_r)),br,lag))

        # Optimize the collected rollout with the multiplier in force during collection.
        # The multiplier is updated only after the PPO update.
        cost_mean=float(np.mean(Cst))

        # Optimize modified Lagrangian return: reward - lambda * cost
        Rlag=np.asarray(R,dtype=np.float32)-lag*np.asarray(Cst,dtype=np.float32)
        with torch.no_grad():
            _,vlast=ac(torch.tensor(obs,dtype=torch.float32).unsqueeze(0)); vlast=float(vlast.item())
        adv=np.zeros(len(Rlag),dtype=np.float32); gae=0.0
        for i in reversed(range(len(Rlag))):
            nv=vlast if i==len(Rlag)-1 else V[i+1]
            dlt=Rlag[i]+cfg['gamma']*nv-V[i]
            gae=dlt+cfg['gamma']*0.95*gae; adv[i]=gae
        ret=adv+np.asarray(V,dtype=np.float32)
        adv=(adv-adv.mean())/(adv.std()+1e-8)
        O=torch.tensor(np.stack(O),dtype=torch.float32); A=torch.tensor(A,dtype=torch.long)
        oldlp=torch.tensor(LP,dtype=torch.float32); Ret=torch.tensor(ret,dtype=torch.float32)
        Adv=torch.tensor(adv,dtype=torch.float32); Masks=torch.tensor(np.stack(M),dtype=torch.bool)
        N=len(Rlag); idx=np.arange(N)
        for _ in range(epochs):
            np.random.shuffle(idx)
            for st in range(0,N,64):
                b=idx[st:st+64]; logits,v=ac(O[b]); dist=masked_dist(logits,Masks[b]); lp=dist.log_prob(A[b])
                ratio=(lp-oldlp[b]).exp(); s1=ratio*Adv[b]; s2=torch.clamp(ratio,0.8,1.2)*Adv[b]
                ploss=-torch.min(s1,s2).mean(); vloss=((v-Ret[b])**2).mean(); ent=dist.entropy().mean()
                loss=ploss+0.5*vloss-0.01*ent
                opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(ac.parameters(),5.0); opt.step()

        lag=float(np.clip(lag + lambda_lr*cost_mean,0.0,lambda_max))

    tr=time.perf_counter()-t0
    def policy(obs,mask,env2):
        ot=torch.tensor(obs,dtype=torch.float32).unsqueeze(0)
        with torch.no_grad(): logits,_=ac(ot); vals=logits[0].numpy(); vals[~mask]=-1e9
        return int(np.argmax(vals))
    return policy,tr,pd.DataFrame(curve,columns=['step','reward_ma','block_H_ma','lambda']),lag


def run_exp4(outdir='/mnt/data',C=50,deltas=(0.20,0.15,0.10),seeds=range(10),train_steps=12000,eval_steps=5000):
    cfg=BASE.copy(); summary=[]; raw=[]; curves=[]

    # DP benchmark from same environment
    dpmod=exp3.dpmod
    sol=dpmod.solve_vi(C,cfg,tol=1e-6,max_iter=2500)
    polmat,dpacts=sol['policy'],sol['actions']
    def dppol(obs,mask,env):
        ai=int(polmat[env.nH,env.nL]); act=dpacts[ai]; return env.actions.index(act)
    dpe=exp3.evaluate_policy(C,cfg,dppol,[70000+s for s in seeds],n_steps=eval_steps)
    for _,r in dpe.iterrows():
        rr=r.to_dict(); rr.update({'method':'DP','delta':np.nan,'train_time_s':sol['solve_time_s'],'lambda_final':np.nan}); raw.append(rr)

    def add_summary(method,delta,df,times,lams=None):
        row={'method':method,'delta':delta,'n_seeds':len(df)}
        for col in ['reward','utilization','block_H','block_L','admit_H','admit_L','price_H','price_L']:
            m,h=mean_ci(df[col].values); row[col]=m; row[col+'_ci95']=h
        tm,th=mean_ci(times); row['train_time_s']=tm; row['train_time_ci95']=th
        if lams is not None:
            lm,lh=mean_ci(lams); row['lambda_final']=lm; row['lambda_final_ci95']=lh
        else:
            row['lambda_final']=np.nan; row['lambda_final_ci95']=np.nan
        # probability of satisfying empirical blocking constraint per seed
        if not (delta is None or (isinstance(delta,float) and np.isnan(delta))):
            row['constraint_satisfaction_rate']=float(np.mean(df['block_H'].values <= delta))
            row['mean_violation']=float(np.mean(np.maximum(df['block_H'].values-delta,0.0)))
        else:
            row['constraint_satisfaction_rate']=np.nan; row['mean_violation']=np.nan
        summary.append(row)

    add_summary('DP',np.nan,dpe,[sol['solve_time_s']]*len(dpe))

    # Standard PPO once; evaluate against each delta for reporting satisfaction.
    ppo_eval=[]; ppo_times=[]
    for s in seeds:
        pol,tr,curve=train_ppo(C,cfg,seed=80000+s,steps=train_steps)
        ev=evaluate_policy(C,cfg,pol,[90000+s],n_steps=eval_steps)
        rr=ev.iloc[0].to_dict(); rr.update({'method':'PPO','delta':np.nan,'train_time_s':tr,'lambda_final':0.0}); raw.append(rr)
        ppo_eval.append(rr); ppo_times.append(tr)
        cc=curve.copy(); cc['method']='PPO'; cc['delta']=np.nan; cc['seed']=s; curves.append(cc)
    ppo_df=pd.DataFrame(ppo_eval)
    add_summary('PPO',np.nan,ppo_df,ppo_times)
    for delta in deltas:
        # duplicate summary of same PPO policy interpreted against each threshold
        row={'method':'PPO','delta':delta,'n_seeds':len(ppo_df)}
        for col in ['reward','utilization','block_H','block_L','admit_H','admit_L','price_H','price_L']:
            m,h=mean_ci(ppo_df[col].values); row[col]=m; row[col+'_ci95']=h
        tm,th=mean_ci(ppo_times); row['train_time_s']=tm; row['train_time_ci95']=th
        row['lambda_final']=0.0; row['lambda_final_ci95']=0.0
        row['constraint_satisfaction_rate']=float(np.mean(ppo_df['block_H'].values <= delta))
        row['mean_violation']=float(np.mean(np.maximum(ppo_df['block_H'].values-delta,0.0)))
        summary.append(row)

    # Lagrangian PPO for each threshold
    for delta in deltas:
        evalrows=[]; times=[]; lams=[]
        for s in seeds:
            print('Constrained PPO delta',delta,'seed',s,flush=True)
            pol,tr,curve,lf=train_lagrangian_ppo(C,cfg,delta=delta,seed=100000+int(delta*1000)+s,steps=train_steps)
            ev=evaluate_policy(C,cfg,pol,[110000+int(delta*1000)+s],n_steps=eval_steps)
            rr=ev.iloc[0].to_dict(); rr.update({'method':'LagPPO','delta':delta,'train_time_s':tr,'lambda_final':lf}); raw.append(rr)
            evalrows.append(rr); times.append(tr); lams.append(lf)
            cc=curve.copy(); cc['method']='LagPPO'; cc['delta']=delta; cc['seed']=s; curves.append(cc)
        df=pd.DataFrame(evalrows); add_summary('LagPPO',delta,df,times,lams)

    sdf=pd.DataFrame(summary); rdf=pd.DataFrame(raw); cdf=pd.concat(curves,ignore_index=True)
    sdf.to_csv(f'{outdir}/exp4_constraint_summary.csv',index=False)
    rdf.to_csv(f'{outdir}/exp4_constraint_raw.csv',index=False)
    cdf.to_csv(f'{outdir}/exp4_constraint_learning_curves.csv',index=False)

    # Figures: reward vs threshold, blocking vs threshold, satisfaction, representative multiplier trajectory.
    lag=sdf[sdf.method=='LagPPO'].sort_values('delta')
    pstd=sdf[(sdf.method=='PPO') & sdf.delta.notna()].sort_values('delta')

    plt.figure(figsize=(7.2,4.6))
    plt.errorbar(lag.delta,lag.reward,yerr=lag.reward_ci95,marker='o',label='Constrained PPO')
    plt.errorbar(pstd.delta,pstd.reward,yerr=pstd.reward_ci95,marker='s',label='Standard PPO')
    dpmean=sdf[sdf.method=='DP'].reward.iloc[0]
    plt.axhline(dpmean,linestyle='--',label='DP benchmark')
    plt.xlabel('Premium blocking constraint $\\delta_H$'); plt.ylabel('Average reward per slot')
    plt.grid(True,alpha=.25); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp4_reward_vs_constraint.png',dpi=220); plt.close()

    plt.figure(figsize=(7.2,4.6))
    plt.errorbar(lag.delta,lag.block_H,yerr=lag.block_H_ci95,marker='o',label='Constrained PPO')
    plt.errorbar(pstd.delta,pstd.block_H,yerr=pstd.block_H_ci95,marker='s',label='Standard PPO')
    plt.plot(lag.delta,lag.delta,linestyle='--',label='Constraint boundary')
    plt.xlabel('Premium blocking constraint $\\delta_H$'); plt.ylabel('Premium blocking probability')
    plt.grid(True,alpha=.25); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp4_blocking_vs_constraint.png',dpi=220); plt.close()

    plt.figure(figsize=(7.2,4.6))
    x=np.arange(len(lag)); w=.35
    plt.bar(x-w/2,lag.constraint_satisfaction_rate,width=w,label='Constrained PPO')
    plt.bar(x+w/2,pstd.constraint_satisfaction_rate,width=w,label='Standard PPO')
    plt.xticks(x,[f'{d:.2f}' for d in lag.delta]); plt.ylim(0,1.05)
    plt.xlabel('Premium blocking constraint $\\delta_H$'); plt.ylabel('Fraction of seeds satisfying constraint')
    plt.grid(True,axis='y',alpha=.25); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp4_constraint_satisfaction.png',dpi=220); plt.close()

    # representative lambda/reward/block curve: delta .15 seed 0
    rep=cdf[(cdf.method=='LagPPO') & (np.isclose(cdf.delta,0.15)) & (cdf.seed==0)]
    if len(rep):
        fig,ax1=plt.subplots(figsize=(7.2,4.6)); ax2=ax1.twinx()
        ax1.plot(rep.step,rep.block_H_ma,label='Premium blocking (MA)')
        ax1.axhline(0.15,linestyle='--',label='Constraint')
        ax2.plot(rep.step,rep['lambda'],linestyle=':',label='Lagrange multiplier')
        ax1.set_xlabel('Training steps'); ax1.set_ylabel('Premium blocking probability'); ax2.set_ylabel('Multiplier')
        lines,labels=ax1.get_legend_handles_labels(); lines2,labels2=ax2.get_legend_handles_labels(); ax1.legend(lines+lines2,labels+labels2,loc='best')
        ax1.grid(True,alpha=.25); fig.tight_layout(); fig.savefig(f'{outdir}/exp4_multiplier_trajectory_delta015.png',dpi=220); plt.close(fig)

    # LaTeX table
    with open(f'{outdir}/exp4_constraint_table.tex','w') as f:
        f.write('\\begin{table}[t]\n\\centering\n\\scriptsize\n')
        f.write('\\caption{SLA-constrained RL at $C=50$. Values are mean $\\pm$ 95\\% CI over 10 seeds.}\n')
        f.write('\\label{tab:exp4_constrained}\n')
        f.write('\\begin{tabular}{llcccc}\n\\hline\n')
        f.write('Method & $\\delta_H$ & Reward & Block H & Block L & Constraint sat. \\\\\n\\hline\n')
        # DP row
        dpr=sdf[sdf.method=='DP'].iloc[0]
        f.write(f"DP & -- & {dpr.reward:.3f}$\\pm${dpr.reward_ci95:.3f} & {dpr.block_H:.3f}$\\pm${dpr.block_H_ci95:.3f} & {dpr.block_L:.3f}$\\pm${dpr.block_L_ci95:.3f} & -- \\\\\n")
        for delta in deltas:
            for meth,label in [('PPO','PPO'),('LagPPO','Constrained PPO')]:
                rr=sdf[(sdf.method==meth)&(np.isclose(sdf.delta,delta))].iloc[0]
                f.write(f"{label} & {delta:.2f} & {rr.reward:.3f}$\\pm${rr.reward_ci95:.3f} & {rr.block_H:.3f}$\\pm${rr.block_H_ci95:.3f} & {rr.block_L:.3f}$\\pm${rr.block_L_ci95:.3f} & {100*rr.constraint_satisfaction_rate:.0f}\\% \\\\\n")
        f.write('\\hline\n\\end{tabular}\n\\end{table}\n')

    return sdf,rdf,cdf

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--capacity',type=int,default=20)
    ap.add_argument('--seeds',type=int,default=1)
    ap.add_argument('--train-steps',type=int,default=5000)
    ap.add_argument('--eval-steps',type=int,default=2500)
    ap.add_argument('--outdir',default='.')
    a=ap.parse_args()
    Path(a.outdir).mkdir(parents=True,exist_ok=True)
    s,r,c=run_exp4(outdir=a.outdir,C=a.capacity,seeds=range(a.seeds),train_steps=a.train_steps,eval_steps=a.eval_steps)
    print(s.to_string(index=False))
