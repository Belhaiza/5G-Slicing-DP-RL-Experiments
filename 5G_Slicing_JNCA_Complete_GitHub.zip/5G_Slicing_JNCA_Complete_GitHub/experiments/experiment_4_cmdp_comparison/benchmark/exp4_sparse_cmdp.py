"""Sparse discounted CMDP LP, exact up to configurable transition pruning tolerance.
Uses vectorized sparse Kronecker transitions and HiGHS dual simplex.
"""
import argparse, json, time
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, kron, hstack, vstack
from scipy.optimize import linprog
from revision_experiments_dp import BASE, build_problem

def solve(C, deltas, tol=1e-12):
    cfg=BASE; gamma=cfg['gamma']; start=time.monotonic()
    mh,ml,used,fs,rho,kh,kl,TH,TL,mhmeta,mlmeta=build_problem(C,cfg)
    states=np.argwhere(fs); ns=len(states); full=(mh+1)*(ml+1)
    flat=states[:,0]*(ml+1)+states[:,1]
    index=np.full(full,-1,dtype=np.int32); index[flat]=np.arange(ns)
    blocks=[]; rewards=[]; costs=[]; arrivals=[]; sizes=[]
    for pH,qH in kh:
        tH=csr_matrix(np.where(TH[(pH,qH)]>tol,TH[(pH,qH)],0))
        lamH,gH,bH=mhmeta[(pH,qH)]
        for pL,qL in kl:
            free=C-cfg['rH']*states[:,0]-cfg['rL']*states[:,1]
            valid=np.flatnonzero(free>=cfg['rH']*qH+cfg['rL']*qL)
            if not len(valid): continue
            tL=csr_matrix(np.where(TL[(pL,qL)]>tol,TL[(pL,qL)],0))
            P=kron(tH,tL,format='csr')[flat[valid],:][:,flat]
            # Each column is (I - gamma P^T) for its origin state.
            origin=coo_matrix((np.ones(len(valid)),(valid,np.arange(len(valid)))),shape=(ns,len(valid))).tocsr()
            blocks.append(origin-gamma*P.T)
            lamL,gL,bL=mlmeta[(pL,qL)]
            rewards.append(pH*gH+pL*gL-cfg['kappa']*rho[states[valid,0],states[valid,1]]**2-cfg['xiH']*bH-cfg['xiL']*bL)
            costs.append(np.full(len(valid),bH)); arrivals.append(np.full(len(valid),lamH)); sizes.append(len(valid))
    A=hstack(blocks,format='csr'); r=np.concatenate(rewards); B=np.concatenate(costs); arr=np.concatenate(arrivals)
    rhs=np.zeros(ns); rhs[index[0]]=1-gamma
    print(f'C={C} states={ns} variables={len(r)} nnz={A.nnz} build_s={time.monotonic()-start:.1f}',flush=True)
    outputs=[]
    for delta in deltas:
        g=B-delta*arr
        t=time.monotonic()
        res=linprog(-r,A_ub=csr_matrix(g.reshape(1,-1)),b_ub=[0],A_eq=A,b_eq=rhs,bounds=(0,None),method='highs-ds',options={'time_limit':240})
        out={'C':C,'delta':delta,'status':int(res.status),'message':res.message,'n_states':ns,'n_state_actions':len(r),'build_seconds':round(t-start,2),'solve_seconds':round(time.monotonic()-t,2),'pruning_threshold':tol}
        if res.success:
            x=res.x; out.update(discounted_reward=float(r@x),premium_blocking_ratio=float(B@x/(arr@x)),constraint_residual=float(g@x),flow_residual_inf=float(np.max(np.abs(A@x-rhs))),total_mass=float(x.sum()))
        outputs.append(out); print(json.dumps(out),flush=True)
    return outputs

if __name__=='__main__':
    p=argparse.ArgumentParser(); p.add_argument('--capacity',type=int,default=20); p.add_argument('--deltas',nargs='+',type=float,default=[.2,.15,.1]);p.add_argument('--output',default='exp4_sparse_results.json');p.add_argument('--prune',type=float,default=1e-12)
    a=p.parse_args(); out=solve(a.capacity,a.deltas,a.prune)
    with open(a.output,'w') as f:json.dump(out,f,indent=2)
