# Experiment 4: SLA-constrained admission and pricing (5G network slicing)

## Status (2026-10-23)

**Verified:** Sparse discounted CMDP occupation-measure LP at C=20 and C=30, with premium blocking thresholds 0.20, 0.15 and 0.10. Results and numerical residuals are in `results/*.json`.

**Not yet verified:** RL comparisons at C=20, C=30, C=50. `rl/` includes a portable *candidate* Lagrangian PPO implementation for testing, not final manuscript results. Do not cite its output until the training and evaluation protocol has been validated. The old C=50 plots are intentionally not included as verified results.

**C=50 exact LP:** not solved; do not claim optimality there.

## Setup

Python 3.10+ recommended:

```bash
python -m venv .venv
# activate your virtual environment
python -m pip install -r requirements.txt
```

## Reproduce exact CMDP benchmark

From the repository root:

```bash
cd benchmark
python exp4_sparse_cmdp.py --capacity 20 --output ../results/recomputed_C20.json
python exp4_sparse_cmdp.py --capacity 30 --output ../results/recomputed_C30.json
```

For deterministic resource use, set `OPENBLAS_NUM_THREADS=1` in the shell before running. In PowerShell: `$env:OPENBLAS_NUM_THREADS='1'`.

The LP uses **normalized discounted** state-action occupancy measures starting from the empty system, gamma=0.99. Its constraint is E_gamma[B_H - delta A_H] <= 0. The reported reward is the normalized discounted reward per slot, **not** a stationary average reward. Transition probabilities <=1e-12 are pruned. Compare the JSON `status`, `flow_residual_inf`, `constraint_residual`, `discounted_reward`, and `premium_blocking_ratio`.

## Candidate constrained PPO experiment

```bash
cd rl
python run_exp4_constrained_ppo.py --capacity 20 --seeds 1 --train-steps 5000 --eval-steps 2500 --outdir ../results/ppo_pilot_C20
```

To run at C=30 or 50, change `--capacity`. Increase seeds to 10 and training steps to 12000 for the original Experiment 4 configuration. This is computationally expensive and **has not been clean-run end-to-end** for this package.

### Important comparison caveat

The PPO evaluation reports empirical finite-horizon average rewards and blocking ratios. Those quantities are not directly comparable as optimality gaps to the LP's discounted objective and discounted SLA. A rigorous LP-versus-PPO gap requires evaluating each policy under a common discounted initial-state distribution or constructing a separate average-reward LP.

### PPO implementation note

The candidate PPO code was changed to update its Lagrange multiplier **after** using the rollout under the multiplier active during collection, rather than applying a newly updated multiplier retrospectively. This is a preliminary consistency correction, not a proof of algorithmic convergence or constraint satisfaction.

## Files

- `benchmark/exp4_sparse_cmdp.py`: sparse LP benchmark.
- `benchmark/revision_experiments_dp.py`: exact two-class transition and reward model.
- `results/exp4_sparse_C20_recheck.json`, `results/exp4_sparse_C30.json`: archived verified LP results.
- `rl/run_exp4_constrained_ppo.py`: candidate constrained PPO and evaluation script.
- `rl/revision_experiments_rl_exp3.py`: shared environment and PPO definitions.
- `rl/revision_experiments_dp.py`: dependency for DP policy benchmark in RL script.

## Reproducibility limitations

Exact numerical timings depend on machine, library versions, and BLAS settings. For publication, pin package versions after a clean environment run and archive the full PPO per-seed output and evaluation protocol. This package is a **verified CMDP benchmark plus an RL replication work-in-progress**, not yet a completed verified Experiment 4 release.
