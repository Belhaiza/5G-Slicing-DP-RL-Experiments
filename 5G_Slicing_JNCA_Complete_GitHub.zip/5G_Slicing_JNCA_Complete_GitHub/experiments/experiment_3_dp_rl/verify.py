import sys, math, numpy as np
sys.path.insert(0,'/mnt/data/exp3_review')
import revision_experiments_rl_exp3 as rl
import importlib.util
s=importlib.util.spec_from_file_location('dp','/mnt/data/revision_experiments_dp.py'); dp=importlib.util.module_from_spec(s);s.loader.exec_module(dp)
assert rl.BASE==dp.BASE
for C in [20,50,100]:
 cfg=dp.BASE; built=dp.build_problem(C,cfg)
 _,_,used,fs,rho,kH,kL,TH,TL,mH,mL=built
 actions=rl.all_actions(cfg)
 assert len(actions)==len(kH)*len(kL)
 for j,a in enumerate(actions):
  pH,pL,qH,qL=a
  assert (pH,qH) in kH and (pL,qL) in kL
  free=C-used; feasible=fs & (2*qH+qL<=free)
  lamH=cfg['lambda0H']*math.exp(-cfg['betaH']*pH);lamL=cfg['lambda0L']*math.exp(-cfg['betaL']*pL)
  gH=dp.g_trunc(lamH,qH);gL=dp.g_trunc(lamL,qL)
  for nH,nL in [(0,0),(min(2,C//2),min(3,C-4)),(C//4,0)]:
   if not feasible[nH,nL]:continue
   e=rl.TwoClassEnv(C,cfg,seed=123)
   e.nH=nH;e.nL=nL
   assert e.feasible_mask()[j]
   r_expected=pH*gH+pL*gL-cfg['kappa']*((2*nH+nL)/C)**2-cfg['xiH']*(lamH-gH)-cfg['xiL']*(lamL-gL)
   rs=[];nxtH=[];nxtL=[]
   for z in range(3500):
    e.nH=nH;e.nL=nL
    _,r,_,_=e.step(j);rs.append(r);nxtH.append(e.nH);nxtL.append(e.nL)
   assert abs(np.mean(rs)-r_expected)<0.19,(C,a,nH,nL,np.mean(rs),r_expected)
   expH=np.dot(np.arange(TH[(pH,qH)].shape[1]),TH[(pH,qH)][nH]);expL=np.dot(np.arange(TL[(pL,qL)].shape[1]),TL[(pL,qL)][nL])
   assert abs(np.mean(nxtH)-expH)<0.22 and abs(np.mean(nxtL)-expL)<0.22
 print('C',C,'all actions: analytic reward, action ordering, feasibility and sampled transitions agree')
print('PASS: model definitions agree for checked configurations')
