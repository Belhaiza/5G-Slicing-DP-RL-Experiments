"""Reproduce Experiment 3 (10 seeds x 3 capacities x 3 RL algorithms)."""
import argparse
from pathlib import Path
import torch
from revision_experiments_rl_exp3 import run_exp3

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', default='reproduced_results')
    ap.add_argument('--seeds', type=int, default=10)
    ap.add_argument('--train-steps', type=int, default=5000)
    ap.add_argument('--eval-steps', type=int, default=2500)
    ap.add_argument('--threads', type=int, default=1)
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    run_exp3(outdir=str(out), seeds=range(args.seeds), train_steps=args.train_steps, eval_steps=args.eval_steps)
