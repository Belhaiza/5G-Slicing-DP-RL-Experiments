# Experiment 3: DP versus Double Q, DQN, and PPO

This repository includes source code, archived summary/figures, and manuscript LaTeX.

## Setup

```bash
python -m venv .venv
# Activate .venv using your operating system's instructions
python -m pip install -r requirements.txt
```

## Run

```bash
python run_reproduce.py --seeds 10 --train-steps 5000 --eval-steps 2500
```

Output is written to `reproduced_results/` (CSV and generated plots). The full run
can be computationally expensive. For a basic functionality check:

```bash
python run_reproduce.py --seeds 1 --train-steps 100 --eval-steps 100
```

`revision_experiments_dp.py` must remain beside `revision_experiments_rl_exp3.py`.

## Verification status

- Source import portability was repaired (no hardcoded /mnt/data DP path).
- A separate clean-directory smoke test passed for Double Q, DQN and PPO.
- A full 10-seed/3-capacity run was attempted but exceeded the execution window;
  **the archived table has not yet been independently reproduced in full**.
- `verify.py` and `verification.log` are prior sampled DP/RL consistency checks;
  the verification script itself uses environment-specific paths and is not
  the recommended public entrypoint.
- The original archived plots and CSV are included as reference outputs.
- Computational timings are hardware-dependent and are not expected to match
  across machines.
