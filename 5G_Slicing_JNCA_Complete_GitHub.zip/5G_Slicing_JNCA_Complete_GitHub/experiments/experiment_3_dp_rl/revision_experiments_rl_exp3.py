import math, time, json, random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import t
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque

# ------------------------------------------------------------
# Two-class shared-capacity environment (matches revised Sec. 3-5)
# ------------------------------------------------------------
BASE = {
    'rH': 2, 'rL': 1,
    'pricesH': (1.0, 2.0, 3.0),
    'pricesL': (0.75, 1.5, 2.25),
    'qmaxH': 2, 'qmaxL': 2,
    'lambda0H': 5.0, 'lambda0L': 7.0,
    'betaH': 0.60, 'betaL': 0.70,
    'muH': 0.25, 'muL': 0.20,
    'gamma': 0.99,
    'kappa': 0.15,
    'xiH': 0.25, 'xiL': 0.15,
}

def all_actions(cfg):
    acts=[]
    for pH in cfg['pricesH']:
        for pL in cfg['pricesL']:
            for qH in range(cfg['qmaxH']+1):
                for qL in range(cfg['qmaxL']+1):
                    acts.append((pH,pL,qH,qL))
    return acts

class TwoClassEnv:
    def __init__(self,C,cfg,seed=0,partial_obs=False):
        self.C=C; self.cfg=cfg.copy(); self.rng=np.random.default_rng(seed)
        self.actions=all_actions(cfg)
        self.partial_obs=partial_obs
        self.maxH=C//cfg['rH']; self.maxL=C//cfg['rL']
        self.reset()
    def reset(self):
        self.nH=0; self.nL=0; self.prev_obs=(0,0)
        return self.obs()
    def obs(self):
        if self.partial_obs:
            nH,nL=self.prev_obs
        else:
            nH,nL=self.nH,self.nL
        return np.array([nH/max(1,self.maxH), nL/max(1,self.maxL)],dtype=np.float32)
    def feasible_mask(self):
        free=self.C-self.cfg['rH']*self.nH-self.cfg['rL']*self.nL
        mask=np.zeros(len(self.actions),dtype=bool)
        for i,(_,_,qH,qL) in enumerate(self.actions):
            mask[i]=(self.cfg['rH']*qH+self.cfg['rL']*qL)<=free
        return mask
    def step(self,ai):
        pH,pL,qH,qL=self.actions[int(ai)]
        c=self.cfg
        lamH=c['lambda0H']*math.exp(-c['betaH']*pH)
        lamL=c['lambda0L']*math.exp(-c['betaL']*pL)
        AH=self.rng.poisson(lamH); AL=self.rng.poisson(lamL)
        YH=min(AH,qH); YL=min(AL,qL)
        BH=AH-YH; BL=AL-YL
        DH=self.rng.binomial(self.nH,c['muH']) if self.nH else 0
        DL=self.rng.binomial(self.nL,c['muL']) if self.nL else 0
        util=(c['rH']*self.nH+c['rL']*self.nL)/self.C
        reward=pH*YH+pL*YL-c['kappa']*util**2-c['xiH']*BH-c['xiL']*BL
        old=(self.nH,self.nL)
        self.nH=self.nH-DH+YH; self.nL=self.nL-DL+YL
        if c['rH']*self.nH+c['rL']*self.nL>self.C:
            raise RuntimeError('capacity infeasible')
        self.prev_obs=old
        info={'utilization':util,'block_H':BH,'block_L':BL,'arr_H':AH,'arr_L':AL,
              'admit_H':YH,'admit_L':YL,'price_H':pH,'price_L':pL}
        return self.obs(),float(reward),False,info

# ------------------------------------------------------------
# DP policy loading from prior solver module
# ------------------------------------------------------------
import importlib.util
spec=importlib.util.spec_from_file_location('dpmod',str(__import__('pathlib').Path(__file__).with_name('revision_experiments_dp.py')))
dpmod=importlib.util.module_from_spec(spec); spec.loader.exec_module(dpmod)

def build_dp_action_map(sol,cfg):
    # dp solver action tuple ordering is (pH,pL,qH,qL), same as env
    return sol['policy'], sol['actions']

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------
def mean_ci(vals):
    vals=np.asarray(vals,float); n=len(vals); m=vals.mean(); s=vals.std(ddof=1) if n>1 else 0
    h=t.ppf(.975,n-1)*s/math.sqrt(n) if n>1 else 0
    return m,h

def evaluate_policy(C,cfg,policy_fn,seeds,n_steps=4000,partial_obs=False):
    rows=[]
    for seed in seeds:
        env=TwoClassEnv(C,cfg,seed=seed,partial_obs=partial_obs)
        obs=env.reset(); rs=[]; us=[]; bh=bl=ah=al=0; yh=yl=0; ph=[]; pl=[]
        for _ in range(n_steps):
            mask=env.feasible_mask(); ai=policy_fn(obs,mask,env)
            obs,r,_,info=env.step(ai)
            rs.append(r); us.append(info['utilization'])
            bh+=info['block_H']; bl+=info['block_L']; ah+=info['arr_H']; al+=info['arr_L']
            yh+=info['admit_H']; yl+=info['admit_L']; ph.append(info['price_H']); pl.append(info['price_L'])
        rows.append({'seed':seed,'reward':np.mean(rs),'utilization':np.mean(us),
                     'block_H':bh/max(1,ah),'block_L':bl/max(1,al),
                     'admit_H':yh/n_steps,'admit_L':yl/n_steps,
                     'price_H':np.mean(ph),'price_L':np.mean(pl)})
    return pd.DataFrame(rows)

# ------------------------------------------------------------
# Double Q-learning
# ------------------------------------------------------------
def train_double_q(C,cfg,seed=0,steps=30000,alpha=0.08,eps0=1.0,eps1=0.05):
    rng=np.random.default_rng(seed); env=TwoClassEnv(C,cfg,seed=seed)
    maxH,maxL=env.maxH,env.maxL; A=len(env.actions)
    Q1=np.zeros((maxH+1,maxL+1,A),dtype=np.float32); Q2=np.zeros_like(Q1)
    env.reset(); curve=[]; rolling=[]
    t0=time.perf_counter()
    for step in range(steps):
        nH,nL=env.nH,env.nL; mask=env.feasible_mask(); feas=np.flatnonzero(mask)
        eps=eps1+(eps0-eps1)*max(0,1-step/(0.8*steps))
        if rng.random()<eps: ai=int(rng.choice(feas))
        else:
            vals=Q1[nH,nL]+Q2[nH,nL]; ai=int(feas[np.argmax(vals[feas])])
        _,r,_,_=env.step(ai); nH2,nL2=env.nH,env.nL; mask2=env.feasible_mask(); feas2=np.flatnonzero(mask2)
        if rng.random()<0.5:
            amax=int(feas2[np.argmax(Q1[nH2,nL2,feas2])])
            target=r+cfg['gamma']*Q2[nH2,nL2,amax]
            Q1[nH,nL,ai]+=alpha*(target-Q1[nH,nL,ai])
        else:
            amax=int(feas2[np.argmax(Q2[nH2,nL2,feas2])])
            target=r+cfg['gamma']*Q1[nH2,nL2,amax]
            Q2[nH,nL,ai]+=alpha*(target-Q2[nH,nL,ai])
        rolling.append(r)
        if len(rolling)>500: rolling.pop(0)
        if (step+1)%500==0: curve.append((step+1,float(np.mean(rolling))))
    tr=time.perf_counter()-t0
    def policy(obs,mask,env2):
        nH,nL=env2.nH,env2.nL; feas=np.flatnonzero(mask); vals=Q1[nH,nL]+Q2[nH,nL]
        return int(feas[np.argmax(vals[feas])])
    return policy,tr,pd.DataFrame(curve,columns=['step','reward_ma'])

# ------------------------------------------------------------
# DQN
# ------------------------------------------------------------
class QNet(nn.Module):
    def __init__(self,nA):
        super().__init__(); self.net=nn.Sequential(nn.Linear(2,32),nn.ReLU(),nn.Linear(32,32),nn.ReLU(),nn.Linear(32,nA))
    def forward(self,x): return self.net(x)

def train_dqn(C,cfg,seed=0,steps=30000,batch=64):
    torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
    rng=np.random.default_rng(seed); env=TwoClassEnv(C,cfg,seed=seed); nA=len(env.actions)
    q=QNet(nA); qt=QNet(nA); qt.load_state_dict(q.state_dict()); opt=optim.Adam(q.parameters(),lr=1e-3)
    buf=deque(maxlen=40000); obs=env.reset(); curve=[]; rolling=[]; t0=time.perf_counter()
    for step in range(steps):
        mask=env.feasible_mask(); feas=np.flatnonzero(mask); eps=0.05+0.95*max(0,1-step/(0.7*steps))
        if rng.random()<eps: ai=int(rng.choice(feas))
        else:
            with torch.no_grad(): vals=q(torch.tensor(obs).unsqueeze(0))[0].numpy()
            ai=int(feas[np.argmax(vals[feas])])
        next_obs,r,_,_=env.step(ai); next_mask=env.feasible_mask().copy()
        buf.append((obs.copy(),ai,r,next_obs.copy(),next_mask)); obs=next_obs
        rolling.append(r); rolling=rolling[-500:]
        if len(buf)>=batch and step%8==0:
            idx=rng.choice(len(buf),batch,replace=False); B=[buf[i] for i in idx]
            s=torch.tensor(np.stack([b[0] for b in B]),dtype=torch.float32)
            a=torch.tensor([b[1] for b in B],dtype=torch.long)
            rr=torch.tensor([b[2] for b in B],dtype=torch.float32)
            ns=torch.tensor(np.stack([b[3] for b in B]),dtype=torch.float32)
            nm=np.stack([b[4] for b in B])
            pred=q(s).gather(1,a[:,None]).squeeze(1)
            with torch.no_grad():
                nq=qt(ns).numpy(); nq[~nm]=-1e9; mx=torch.tensor(nq.max(axis=1),dtype=torch.float32)
                target=rr+cfg['gamma']*mx
            loss=((pred-target)**2).mean(); opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(q.parameters(),5.0); opt.step()
        if (step+1)%1000==0: qt.load_state_dict(q.state_dict())
        if (step+1)%500==0: curve.append((step+1,float(np.mean(rolling))))
    tr=time.perf_counter()-t0
    def policy(obs,mask,env2):
        feas=np.flatnonzero(mask)
        with torch.no_grad(): vals=q(torch.tensor(obs).unsqueeze(0))[0].numpy()
        return int(feas[np.argmax(vals[feas])])
    return policy,tr,pd.DataFrame(curve,columns=['step','reward_ma'])

# ------------------------------------------------------------
# PPO with action masking
# ------------------------------------------------------------
class ActorCritic(nn.Module):
    def __init__(self,nA):
        super().__init__(); self.body=nn.Sequential(nn.Linear(2,32),nn.Tanh(),nn.Linear(32,32),nn.Tanh())
        self.pi=nn.Linear(32,nA); self.v=nn.Linear(32,1)
    def forward(self,x):
        z=self.body(x); return self.pi(z),self.v(z).squeeze(-1)

def masked_dist(logits,mask):
    ml=logits.clone(); ml[~mask]=-1e9; return torch.distributions.Categorical(logits=ml)

def train_ppo(C,cfg,seed=0,steps=30000,rollout=512,epochs=4):
    torch.manual_seed(seed); np.random.seed(seed); random.seed(seed)
    env=TwoClassEnv(C,cfg,seed=seed); nA=len(env.actions); ac=ActorCritic(nA); opt=optim.Adam(ac.parameters(),lr=3e-4)
    obs=env.reset(); done_steps=0; curve=[]; rolling=[]; t0=time.perf_counter()
    while done_steps<steps:
        O=[]; A=[]; R=[]; LP=[]; V=[]; M=[]
        for _ in range(min(rollout,steps-done_steps)):
            mask_np=env.feasible_mask(); mask=torch.tensor(mask_np,dtype=torch.bool).unsqueeze(0)
            ot=torch.tensor(obs,dtype=torch.float32).unsqueeze(0)
            with torch.no_grad(): logits,val=ac(ot); dist=masked_dist(logits,mask); act=dist.sample(); lp=dist.log_prob(act)
            nobs,r,_,_=env.step(int(act.item()))
            O.append(obs.copy()); A.append(int(act.item())); R.append(r); LP.append(float(lp.item())); V.append(float(val.item())); M.append(mask_np.copy())
            obs=nobs; rolling.append(r); rolling=rolling[-500:]; done_steps+=1
            if done_steps%500==0: curve.append((done_steps,float(np.mean(rolling))))
        with torch.no_grad(): _,vlast=ac(torch.tensor(obs,dtype=torch.float32).unsqueeze(0)); vlast=float(vlast.item())
        adv=np.zeros(len(R),dtype=np.float32); gae=0.0
        for i in reversed(range(len(R))):
            nv=vlast if i==len(R)-1 else V[i+1]
            delta=R[i]+cfg['gamma']*nv-V[i]; gae=delta+cfg['gamma']*0.95*gae; adv[i]=gae
        ret=adv+np.array(V,dtype=np.float32); adv=(adv-adv.mean())/(adv.std()+1e-8)
        O=torch.tensor(np.stack(O),dtype=torch.float32); A=torch.tensor(A); oldlp=torch.tensor(LP); Ret=torch.tensor(ret); Adv=torch.tensor(adv); Masks=torch.tensor(np.stack(M),dtype=torch.bool)
        N=len(R); idx=np.arange(N)
        for _ in range(epochs):
            np.random.shuffle(idx)
            for st in range(0,N,64):
                b=idx[st:st+64]; logits,v=ac(O[b]); dist=masked_dist(logits,Masks[b]); lp=dist.log_prob(A[b]); ratio=(lp-oldlp[b]).exp()
                s1=ratio*Adv[b]; s2=torch.clamp(ratio,0.8,1.2)*Adv[b]
                ploss=-torch.min(s1,s2).mean(); vloss=((v-Ret[b])**2).mean(); ent=dist.entropy().mean()
                loss=ploss+0.5*vloss-0.01*ent; opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(ac.parameters(),5.0); opt.step()
    tr=time.perf_counter()-t0
    def policy(obs,mask,env2):
        ot=torch.tensor(obs,dtype=torch.float32).unsqueeze(0); mt=torch.tensor(mask,dtype=torch.bool).unsqueeze(0)
        with torch.no_grad(): logits,_=ac(ot); logits=logits[0].numpy(); logits[~mask]=-1e9
        return int(np.argmax(logits))
    return policy,tr,pd.DataFrame(curve,columns=['step','reward_ma'])

# ------------------------------------------------------------
# Experiment 3 runner
# ------------------------------------------------------------
def run_exp3(outdir='/mnt/data',Cs=(20,50,100),seeds=range(10),train_steps=8000,eval_steps=3000):
    summary=[]; curve_rows=[]
    for C in Cs:
        cfg=BASE.copy(); print('Solving DP C',C,flush=True)
        sol=dpmod.solve_vi(C,cfg,tol=1e-6,max_iter=2500)
        polmat,dpacts=build_dp_action_map(sol,cfg)
        def dppol(obs,mask,env):
            ai=int(polmat[env.nH,env.nL]); act=dpacts[ai]; return env.actions.index(act)
        dpeval=evaluate_policy(C,cfg,dppol,[10000+s for s in seeds],n_steps=eval_steps)
        m,h=mean_ci(dpeval.reward); summary.append({'C':C,'method':'DP','reward':m,'reward_ci95':h,'train_time_s':sol['solve_time_s'],
            'utilization':dpeval.utilization.mean(),'block_H':dpeval.block_H.mean(),'block_L':dpeval.block_L.mean()})
        for method,trainer in [('DoubleQ',train_double_q),('DQN',train_dqn),('PPO',train_ppo)]:
            evalrows=[]; times=[]
            for s in seeds:
                print('Train',method,'C',C,'seed',s,flush=True)
                pol,tr,curve=trainer(C,cfg,seed=1000*C+s,steps=train_steps)
                ev=evaluate_policy(C,cfg,pol,[20000+s],n_steps=eval_steps)
                row=ev.iloc[0].to_dict(); row['seed']=s; evalrows.append(row); times.append(tr)
                curve['C']=C; curve['method']=method; curve['seed']=s; curve_rows.append(curve)
            edf=pd.DataFrame(evalrows); m,h=mean_ci(edf.reward)
            summary.append({'C':C,'method':method,'reward':m,'reward_ci95':h,'train_time_s':np.mean(times),
                'utilization':edf.utilization.mean(),'block_H':edf.block_H.mean(),'block_L':edf.block_L.mean()})
    sdf=pd.DataFrame(summary); cdf=pd.concat(curve_rows,ignore_index=True)
    sdf.to_csv(f'{outdir}/exp3_dp_rl_summary.csv',index=False); cdf.to_csv(f'{outdir}/exp3_learning_curves.csv',index=False)
    # reward by capacity
    plt.figure(figsize=(7,4.5))
    for method,g in sdf.groupby('method'):
        plt.errorbar(g.C,g.reward,yerr=g.reward_ci95,marker='o',capsize=3,label=method)
    plt.xlabel('Shared PRB capacity C'); plt.ylabel('Average reward per slot'); plt.grid(True,alpha=.3); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp3_reward_vs_capacity.png',dpi=220); plt.close()
    # train time
    plt.figure(figsize=(7,4.5))
    for method,g in sdf.groupby('method'):
        plt.plot(g.C,g.train_time_s,marker='o',label=method)
    plt.xlabel('Shared PRB capacity C'); plt.ylabel('Solve / training time (s)'); plt.grid(True,alpha=.3); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp3_time_vs_capacity.png',dpi=220); plt.close()
    # learning curves at C=50 averaged across seeds
    c50=cdf[cdf.C==50]
    plt.figure(figsize=(7,4.5))
    for method,g in c50.groupby('method'):
        agg=g.groupby('step').reward_ma.agg(['mean','std']).reset_index(); plt.plot(agg.step,agg['mean'],label=method); plt.fill_between(agg.step,agg['mean']-agg['std'],agg['mean']+agg['std'],alpha=.15)
    plt.xlabel('Training steps'); plt.ylabel('Moving-average training reward'); plt.grid(True,alpha=.3); plt.legend(); plt.tight_layout(); plt.savefig(f'{outdir}/exp3_learning_curves_C50.png',dpi=220); plt.close()
    return sdf,cdf

if __name__=='__main__':
    print(json.dumps(BASE,indent=2)); run_exp3()
